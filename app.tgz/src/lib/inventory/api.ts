import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { addDays, todayISO } from "@/lib/inventory/model";
import { splitSerials, consumeSerials } from "@/lib/inventory/serials";

export type PaymentStatus = "received" | "partial" | "unpaid";
export type MovementKind = "delivery" | "return" | "purchase";

export type EntryDraft = {
  companyName: string;
  entryDate: string;
  serialNo: string;
  quantity: number;
  paymentStatus: PaymentStatus;
  amountDue: number | null;
  amountPaid: number | null;
  note: string;
  movement: MovementKind;
  unitPrice: number | null;
  billNo: string;
  parentId: string | null;
  qtyOverride: boolean;
  cylinderType: string;
};

export type Entry = Omit<EntryDraft, "qtyOverride"> & {
  id: string;
  createdBy: string;
  updatedAt: string;
};

export type YardInfo = {
  id: string;
  name: string;
  inviteCode: string;
  role: string;
  members: number;
  address: string;
  gst: string;
  pan: string;
  phone: string;
  logo: string;
  yards: Array<{ id: string; name: string; active: boolean }>;
};

export type Letterhead = {
  address: string;
  gst: string;
  pan: string;
  phone: string;
  logo: string;
};

export type DocRecord = {
  id: string;
  companyName: string;
  title: string;
  kind: string;
  mime: string;
  content: string;
  createdAt: string;
};

export type ReturnLog = {
  id: string;
  entryId: string | null;
  companyName: string;
  serials: string;
  quantity: number;
  actor: string;
  createdAt: string;
};

export type ReturnDraft = {
  entryId: string;
  serials: string[];
  quantity: number;
  note: string;
};

const STATUSES: PaymentStatus[] = ["received", "partial", "unpaid"];
const MOVEMENTS: MovementKind[] = ["delivery", "return", "purchase"];

export function parseEntry(input: EntryDraft): { ok: true; value: EntryDraft } | { ok: false; error: string } {
  const companyName = input.companyName.trim();
  if (!companyName) return { ok: false, error: "Enter the company name." };
  if (companyName.length > 120) return { ok: false, error: "Company name is too long." };
  if (!isRealDate(input.entryDate)) return { ok: false, error: "Pick a valid date." };
  const serials = splitSerials(input.serialNo);
  const serialNo = serials.join("\n");
  if (serialNo.length > 2000) return { ok: false, error: "Serial numbers are too long." };
  if (!MOVEMENTS.includes(input.movement)) return { ok: false, error: "Pick delivery, purchase, or return." };
  const quantity = input.qtyOverride ? input.quantity : serials.length > 0 ? serials.length : input.quantity;
  if (!Number.isInteger(quantity) || quantity < 1 || quantity > 100000) {
    if (!input.qtyOverride && serials.length === 0) {
      return { ok: false, error: "Add serial numbers, or turn on Override quantity." };
    }
    return { ok: false, error: "Number of cylinders has to be a whole number from 1 to 100000." };
  }
  if (!STATUSES.includes(input.paymentStatus)) return { ok: false, error: "Pick a payment status." };
  const amountDue = cleanMoney(input.amountDue);
  const amountPaid = cleanMoney(input.amountPaid);
  const unitPrice = cleanMoney(input.unitPrice);
  if (amountDue === "bad" || amountPaid === "bad" || unitPrice === "bad") {
    return { ok: false, error: "Amounts have to be zero or more." };
  }
  const note = input.note.trim();
  if (note.length > 300) return { ok: false, error: "Note is too long." };
  const billNo = input.billNo.trim().slice(0, 40);
  const cylinderType = (input.cylinderType ?? "").trim().slice(0, 60);
  const parentId = input.parentId?.trim() ? input.parentId.trim().slice(0, 80) : null;
  return {
    ok: true,
    value: {
      companyName,
      entryDate: input.entryDate,
      serialNo,
      quantity,
      paymentStatus: input.paymentStatus,
      amountDue,
      amountPaid,
      note,
      movement: input.movement,
      unitPrice,
      billNo,
      parentId,
      qtyOverride: input.qtyOverride,
      cylinderType,
    },
  };
}

function isRealDate(iso: string): boolean {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(iso)) return false;
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(y!, (m ?? 1) - 1, d ?? 1);
  return dt.getFullYear() === y && dt.getMonth() === (m ?? 1) - 1 && dt.getDate() === d;
}

function cleanMoney(value: number | null): number | null | "bad" {
  if (value == null) return null;
  if (typeof value !== "number" || !Number.isFinite(value) || value < 0 || value > 1_000_000_000) return "bad";
  return Math.round(value * 100) / 100;
}

type YardRow = {
  id: string;
  name: string;
  invite_code: string;
  role: string;
  address: string;
  gst: string;
  pan: string;
  phone: string;
  logo: string;
};

type EntryRow = {
  id: string;
  company_name: string;
  entry_date: string;
  serial_no: string;
  quantity: number;
  payment_status: PaymentStatus;
  amount_due: number | string | null;
  amount_paid: number | string | null;
  note: string;
  created_by: string;
  updated_at: string;
  movement: string;
  unit_price: number | string | null;
  bill_no: string;
  parent_id: string | null;
  cylinder_type: string | null;
};

async function sqlClient() {
  const { getSql } = await import("@/lib/db");
  return getSql();
}

function inviteCode(): string {
  const alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  const bytes = crypto.getRandomValues(new Uint8Array(8));
  return Array.from(bytes, (b) => alphabet[b % alphabet.length]).join("");
}

function asMovement(value: string): MovementKind {
  if (value === "return" || value === "purchase") return value;
  return "delivery";
}

async function ensureYard(userId: string): Promise<YardInfo> {
  const sql = await sqlClient();
  await sql`insert into profiles (user_id) values (${userId}) on conflict (user_id) do nothing`;

  const linked = await sql<YardRow>`
    select y.id, y.name, y.invite_code, m.role, y.address, y.gst, y.pan, y.phone, y.logo
    from profiles p
    join yards y on y.id = p.active_yard_id
    join yard_members m on m.yard_id = y.id and m.user_id = p.user_id
    where p.user_id = ${userId}
  `;
  let current = linked[0];
  if (!current) {
    const any = await sql<YardRow>`
      select y.id, y.name, y.invite_code, m.role, y.address, y.gst, y.pan, y.phone, y.logo
      from yard_members m
      join yards y on y.id = m.yard_id
      where m.user_id = ${userId}
      order by m.joined_at
      limit 1
    `;
    current = any[0];
    if (current) {
      await sql`update profiles set active_yard_id = ${current.id} where user_id = ${userId}`;
    }
  }
  if (!current) {
    current = await insertYard(userId, "My yard");
  }

  const yards = await sql<{ id: string; name: string }>`
    select y.id, y.name
    from yard_members m
    join yards y on y.id = m.yard_id
    where m.user_id = ${userId}
    order by y.name
  `;
  const counts = await sql<{ members: number }>`
    select count(*)::int as members from yard_members where yard_id = ${current.id}
  `;
  return mapYard(current, Number(counts[0]?.members ?? 1), yards);
}

async function insertYard(userId: string, name: string): Promise<YardRow> {
  const sql = await sqlClient();
  const id = crypto.randomUUID();
  let code = inviteCode();
  for (let i = 0; i < 5; i += 1) {
    const clash = await sql<{ id: string }>`select id from yards where invite_code = ${code}`;
    if (!clash.length) break;
    code = inviteCode();
  }
  await sql`
    insert into yards (id, name, invite_code, created_by)
    values (${id}, ${name}, ${code}, ${userId})
  `;
  await sql`
    insert into yard_members (yard_id, user_id, role)
    values (${id}, ${userId}, ${"owner"})
  `;
  await sql`insert into profiles (user_id, active_yard_id) values (${userId}, ${id})
    on conflict (user_id) do update set active_yard_id = ${id}`;
  return {
    id,
    name,
    invite_code: code,
    role: "owner",
    address: "",
    gst: "",
    pan: "",
    phone: "",
    logo: "",
  };
}

function mapYard(current: YardRow, members: number, yards: Array<{ id: string; name: string }>): YardInfo {
  return {
    id: current.id,
    name: current.name,
    inviteCode: current.invite_code,
    role: current.role,
    members,
    address: current.address ?? "",
    gst: current.gst ?? "",
    pan: current.pan ?? "",
    phone: current.phone ?? "",
    logo: current.logo ?? "",
    yards: yards.map((yard) => ({ id: yard.id, name: yard.name, active: yard.id === current.id })),
  };
}

function mapEntry(row: EntryRow): Entry {
  return {
    id: row.id,
    companyName: row.company_name,
    entryDate: String(row.entry_date).slice(0, 10),
    serialNo: row.serial_no,
    quantity: Number(row.quantity),
    paymentStatus: row.payment_status,
    amountDue: row.amount_due == null ? null : Number(row.amount_due),
    amountPaid: row.amount_paid == null ? null : Number(row.amount_paid),
    note: row.note,
    createdBy: row.created_by,
    updatedAt: String(row.updated_at),
    movement: asMovement(row.movement),
    unitPrice: row.unit_price == null ? null : Number(row.unit_price),
    billNo: row.bill_no ?? "",
    parentId: row.parent_id,
    cylinderType: row.cylinder_type ?? "",
  };
}

export const getYard = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => ensureYard(context.userId));

export const listEntries = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const rows = await sql<EntryRow>`
      select id, company_name, entry_date::text as entry_date, serial_no, quantity, payment_status,
             amount_due::float8 as amount_due, amount_paid::float8 as amount_paid,
             note, created_by, updated_at::text as updated_at,
             movement, unit_price::float8 as unit_price, bill_no, parent_id, cylinder_type
      from entries
      where yard_id = ${yard.id}
      order by entry_date desc, updated_at desc
      limit 2000
    `;
    return rows.map(mapEntry);
  });

export const createEntry = createServerFn({ method: "POST" })
  .validator((input: EntryDraft) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const parsed = parseEntry(data);
    if (!parsed.ok) return parsed;
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const id = crypto.randomUUID();
    const value = parsed.value;
    const rows = await sql<EntryRow>`
      insert into entries (
        id, yard_id, created_by, company_name, entry_date, serial_no, quantity,
        payment_status, amount_due, amount_paid, note, movement, unit_price, bill_no, parent_id, cylinder_type
      ) values (
        ${id}, ${yard.id}, ${context.userId}, ${value.companyName}, ${value.entryDate}, ${value.serialNo},
        ${value.quantity}, ${value.paymentStatus}, ${value.amountDue}, ${value.amountPaid}, ${value.note},
        ${value.movement}, ${value.unitPrice}, ${value.billNo}, ${value.parentId}, ${value.cylinderType}
      )
      returning id, company_name, entry_date::text as entry_date, serial_no, quantity, payment_status,
                amount_due::float8 as amount_due, amount_paid::float8 as amount_paid,
                note, created_by, updated_at::text as updated_at,
                movement, unit_price::float8 as unit_price, bill_no, parent_id, cylinder_type
    `;
    return { ok: true as const, entry: mapEntry(rows[0]!) };
  });

export const updateEntry = createServerFn({ method: "POST" })
  .validator((input: EntryDraft & { id: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const parsed = parseEntry(data);
    if (!parsed.ok) return parsed;
    if (!data.id) return { ok: false as const, error: "Missing entry." };
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const value = parsed.value;
    const rows = await sql<EntryRow>`
      update entries set
        company_name = ${value.companyName},
        entry_date = ${value.entryDate},
        serial_no = ${value.serialNo},
        quantity = ${value.quantity},
        payment_status = ${value.paymentStatus},
        amount_due = ${value.amountDue},
        amount_paid = ${value.amountPaid},
        note = ${value.note},
        movement = ${value.movement},
        unit_price = ${value.unitPrice},
        bill_no = ${value.billNo},
        parent_id = ${value.parentId},
        cylinder_type = ${value.cylinderType},
        updated_at = now()
      where id = ${data.id} and yard_id = ${yard.id}
      returning id, company_name, entry_date::text as entry_date, serial_no, quantity, payment_status,
                amount_due::float8 as amount_due, amount_paid::float8 as amount_paid,
                note, created_by, updated_at::text as updated_at,
                movement, unit_price::float8 as unit_price, bill_no, parent_id, cylinder_type
    `;
    if (!rows[0]) return { ok: false as const, error: "That entry is not in this account." };
    return { ok: true as const, entry: mapEntry(rows[0]) };
  });

export const deleteEntry = createServerFn({ method: "POST" })
  .validator((id: string) => id)
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const rows = await sql<{ id: string }>`
      delete from entries where id = ${id} and yard_id = ${yard.id} returning id
    `;
    return { ok: rows.length > 0 };
  });

export const recordReturn = createServerFn({ method: "POST" })
  .validator((input: ReturnDraft) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    if (!data.entryId) return { ok: false as const, error: "Pick an open delivery." };
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const parents = await sql<EntryRow>`
      select id, company_name, entry_date::text as entry_date, serial_no, quantity, payment_status,
             amount_due::float8 as amount_due, amount_paid::float8 as amount_paid,
             note, created_by, updated_at::text as updated_at,
             movement, unit_price::float8 as unit_price, bill_no, parent_id, cylinder_type
      from entries
      where id = ${data.entryId} and yard_id = ${yard.id}
    `;
    const parent = parents[0];
    if (!parent || asMovement(parent.movement) !== "delivery") {
      return { ok: false as const, error: "Pick an open delivery." };
    }
    const children = await sql<{ quantity: number; serial_no: string }>`
      select quantity, serial_no from entries
      where yard_id = ${yard.id} and parent_id = ${data.entryId} and movement = ${"return"}
    `;
    const returnedQty = children.reduce((total, row) => total + Number(row.quantity), 0);
    const leftQty = Number(parent.quantity) - returnedQty;
    const parentSerials = splitSerials(parent.serial_no);
    const leftSerials = consumeSerials(
      parentSerials,
      children.flatMap((row) => splitSerials(row.serial_no)),
    );
    if (leftQty < 1) return { ok: false as const, error: "That delivery is already fully received." };

    let serialNo = "";
    let quantity = 0;
    if (parentSerials.length > 0) {
      const picked = splitSerials((data.serials ?? []).join("\n"));
      const allowed = new Set(leftSerials.map((serial) => serial.toLowerCase()));
      if (!picked.length || picked.some((serial) => !allowed.has(serial.toLowerCase()))) {
        return { ok: false as const, error: "Choose serials that are still out on that delivery." };
      }
      serialNo = picked.join("\n");
      quantity = picked.length;
      if (quantity > leftQty) return { ok: false as const, error: "That is more cylinders than are still out." };
    } else {
      quantity = Math.floor(Number(data.quantity));
      if (!Number.isInteger(quantity) || quantity < 1 || quantity > leftQty) {
        return { ok: false as const, error: `Enter a count from 1 to ${leftQty}.` };
      }
    }

    const note = (data.note ?? "").trim().slice(0, 300) || "Marked received";
    const id = crypto.randomUUID();
    const today = todayISO();
    await sql`
      insert into entries (
        id, yard_id, created_by, company_name, entry_date, serial_no, quantity,
        payment_status, amount_due, amount_paid, note, movement, unit_price, bill_no, parent_id, cylinder_type
      ) values (
        ${id}, ${yard.id}, ${context.userId}, ${parent.company_name}, ${today}, ${serialNo},
        ${quantity}, ${"received"}, ${null}, ${null}, ${note},
        ${"return"}, ${null}, ${""}, ${parent.id}, ${parent.cylinder_type ?? ""}
      )
    `;
    await sql`
      insert into return_logs (id, yard_id, entry_id, company_name, serials, quantity, actor)
      values (${crypto.randomUUID()}, ${yard.id}, ${parent.id}, ${parent.company_name}, ${serialNo}, ${quantity}, ${context.userId})
    `;
    return { ok: true as const };
  });

export const listReturns = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const rows = await sql<{
      id: string;
      entry_id: string | null;
      company_name: string;
      serials: string;
      quantity: number;
      actor: string;
      created_at: string;
    }>`
      select id, entry_id, company_name, serials, quantity, actor, created_at::text as created_at
      from return_logs
      where yard_id = ${yard.id}
      order by created_at desc
      limit 200
    `;
    return rows.map(
      (row): ReturnLog => ({
        id: row.id,
        entryId: row.entry_id,
        companyName: row.company_name,
        serials: row.serials,
        quantity: Number(row.quantity),
        actor: row.actor,
        createdAt: row.created_at,
      }),
    );
  });

export const listDocuments = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const rows = await sql<{
      id: string;
      company_name: string;
      title: string;
      kind: string;
      mime: string;
      content: string;
      created_at: string;
    }>`
      select id, company_name, title, kind, mime, content, created_at::text as created_at
      from documents
      where yard_id = ${yard.id}
      order by created_at desc
      limit 80
    `;
    return rows.map(
      (row): DocRecord => ({
        id: row.id,
        companyName: row.company_name,
        title: row.title,
        kind: row.kind,
        mime: row.mime,
        content: row.content,
        createdAt: row.created_at,
      }),
    );
  });

export const saveDocument = createServerFn({ method: "POST" })
  .validator((input: { companyName: string; title: string; kind: string; mime: string; content: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const title = data.title.trim().slice(0, 120);
    const companyName = data.companyName.trim().slice(0, 120);
    if (!title) return { ok: false as const, error: "Name the file." };
    if (!data.content || data.content.length > 400_000) {
      return { ok: false as const, error: "That file is too large. Keep each upload under 280 KB." };
    }
    const kind = data.kind === "bill" || data.kind === "report" ? data.kind : "upload";
    const mime = data.mime.trim().slice(0, 80) || "application/octet-stream";
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const id = crypto.randomUUID();
    await sql`
      insert into documents (id, yard_id, company_name, title, kind, mime, content, created_by)
      values (${id}, ${yard.id}, ${companyName}, ${title}, ${kind}, ${mime}, ${data.content}, ${context.userId})
    `;
    return { ok: true as const, id };
  });

export const deleteDocument = createServerFn({ method: "POST" })
  .validator((id: string) => id)
  .middleware([authMiddleware])
  .handler(async ({ context, data: id }) => {
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const rows = await sql<{ id: string }>`
      delete from documents where id = ${id} and yard_id = ${yard.id} returning id
    `;
    return { ok: rows.length > 0 };
  });

export const renameYard = createServerFn({ method: "POST" })
  .validator((name: string) => name)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const name = data.trim().slice(0, 60);
    if (!name) return { ok: false as const, error: "Enter your company name." };
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    await sql`update yards set name = ${name} where id = ${yard.id}`;
    return { ok: true as const, name };
  });

export const saveLetterhead = createServerFn({ method: "POST" })
  .validator((input: Letterhead) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const address = data.address.trim().slice(0, 240);
    const gst = data.gst.trim().slice(0, 20);
    const pan = data.pan.trim().slice(0, 12);
    const phone = data.phone.trim().slice(0, 24);
    const logo = data.logo.startsWith("data:image/") ? data.logo.slice(0, 120_000) : "";
    if (data.logo && !logo) return { ok: false as const, error: "Logo needs to be a small image." };
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    await sql`
      update yards set address = ${address}, gst = ${gst}, pan = ${pan}, phone = ${phone}, logo = ${logo}
      where id = ${yard.id}
    `;
    return { ok: true as const };
  });

export const createYard = createServerFn({ method: "POST" })
  .validator((name: string) => name)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const name = data.trim().slice(0, 60);
    if (!name) return { ok: false as const, error: "Name the new account." };
    await insertYard(context.userId, name);
    return { ok: true as const };
  });

export const joinYard = createServerFn({ method: "POST" })
  .validator((code: string) => code)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const code = data.trim().toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (code.length < 6) return { ok: false as const, error: "Enter the full yard code." };
    const sql = await sqlClient();
    const found = await sql<{ id: string }>`select id from yards where invite_code = ${code}`;
    if (!found[0]) return { ok: false as const, error: "No account uses that code." };
    await sql`
      insert into yard_members (yard_id, user_id, role)
      values (${found[0].id}, ${context.userId}, ${"member"})
      on conflict (yard_id, user_id) do nothing
    `;
    await sql`insert into profiles (user_id) values (${context.userId}) on conflict (user_id) do nothing`;
    await sql`update profiles set active_yard_id = ${found[0].id} where user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const switchYard = createServerFn({ method: "POST" })
  .validator((yardId: string) => yardId)
  .middleware([authMiddleware])
  .handler(async ({ context, data: yardId }) => {
    const sql = await sqlClient();
    const member = await sql<{ yard_id: string }>`
      select yard_id from yard_members where yard_id = ${yardId} and user_id = ${context.userId}
    `;
    if (!member[0]) return { ok: false as const, error: "You are not in that account." };
    await sql`update profiles set active_yard_id = ${yardId} where user_id = ${context.userId}`;
    return { ok: true as const };
  });

export const seedSample = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const existing = await sql<{ count: number }>`select count(*)::int as count from entries where yard_id = ${yard.id}`;
    if (Number(existing[0]?.count ?? 0) > 0) {
      return { ok: false as const, error: "Sample data is only added to an empty account." };
    }
    const today = todayISO();
    const rows = [
      {
        company: "Sharma Stores",
        date: addDays(today, -2),
        serials: "S-44101\nS-44102\nS-44103",
        qty: 3,
        status: "received",
        due: 3300,
        paid: 3300 as number | null,
        price: 1100,
        bill: "CX-SAMPLE-01",
        note: "Domestic 14.2 kg",
      },
      {
        company: "Metro Kitchen",
        date: addDays(today, -1),
        serials: "S-19021\nS-19022",
        qty: 2,
        status: "partial",
        due: 3700,
        paid: 1000 as number | null,
        price: 1850,
        bill: "CX-SAMPLE-02",
        note: "Commercial 19 kg",
      },
      {
        company: "City Hospital",
        date: today,
        serials: "S-47501",
        qty: 1,
        status: "unpaid",
        due: 4200,
        paid: null as number | null,
        price: 4200,
        bill: "CX-SAMPLE-03",
        note: "Industrial 47.5 kg",
      },
    ];
    let firstId = "";
    for (const row of rows) {
      const id = crypto.randomUUID();
      if (!firstId) firstId = id;
      await sql`
        insert into entries (
          id, yard_id, created_by, company_name, entry_date, serial_no, quantity,
          payment_status, amount_due, amount_paid, note, movement, unit_price, bill_no, cylinder_type
        ) values (
          ${id}, ${yard.id}, ${context.userId}, ${row.company}, ${row.date}, ${row.serials}, ${row.qty},
          ${row.status}, ${row.due}, ${row.paid}, ${row.note}, ${"delivery"}, ${row.price}, ${row.bill}, ${row.note}
        )
      `;
    }
    await sql`
      insert into entries (
        id, yard_id, created_by, company_name, entry_date, serial_no, quantity,
        payment_status, note, movement, bill_no, parent_id, cylinder_type
      ) values (
        ${crypto.randomUUID()}, ${yard.id}, ${context.userId}, ${"Sharma Stores"}, ${today}, ${"S-44101"}, ${1},
        ${"received"}, ${"Sample return"}, ${"return"}, ${""}, ${firstId}, ${"Domestic 14.2 kg"}
      )
    `;
    await sql`
      insert into return_logs (id, yard_id, entry_id, company_name, serials, quantity, actor)
      values (${crypto.randomUUID()}, ${yard.id}, ${firstId}, ${"Sharma Stores"}, ${"S-44101"}, ${1}, ${context.userId})
    `;
    return { ok: true as const };
  });

export type CompanyMeta = { companyName: string; keywords: string; notes: string; updatedAt: string };

export const listCompanyMeta = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    const rows = await sql<{ company_name: string; keywords: string; notes: string; updated_at: string }>`
      select company_name, keywords, notes, updated_at::text as updated_at
      from company_meta
      where yard_id = ${yard.id}
    `;
    return rows.map(
      (row): CompanyMeta => ({ companyName: row.company_name, keywords: row.keywords, notes: row.notes, updatedAt: row.updated_at }),
    );
  });

export const saveCompanyMeta = createServerFn({ method: "POST" })
  .validator((input: { companyName: string; keywords: string; notes: string }) => input)
  .middleware([authMiddleware])
  .handler(async ({ context, data }) => {
    const companyName = data.companyName.trim().slice(0, 120);
    if (!companyName) return { ok: false as const, error: "Pick a company." };
    const keywords = data.keywords.trim().slice(0, 300);
    const notes = data.notes.trim().slice(0, 1000);
    const yard = await ensureYard(context.userId);
    const sql = await sqlClient();
    await sql`
      insert into company_meta (yard_id, company_name, keywords, notes)
      values (${yard.id}, ${companyName}, ${keywords}, ${notes})
      on conflict (yard_id, company_name) do update set keywords = ${keywords}, notes = ${notes}, updated_at = now()
    `;
    return { ok: true as const };
  });
