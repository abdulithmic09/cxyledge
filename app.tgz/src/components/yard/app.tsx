import { lazy, Suspense, useEffect, useState } from "react";
import { QueryClient, QueryClientProvider, useQuery, useQueryClient } from "@tanstack/react-query";
import { Building2, Cylinder, LayoutList, PieChart, Receipt, Settings } from "lucide-react";
import { SignInPanel } from "@/components/yard/sign-in-panel";
import { UserButton } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { getYard, listDocuments, listEntries, listReturns } from "@/lib/inventory/api";
import { applyLook, readLook } from "@/lib/inventory/look";
import { cn } from "@/lib/cn";
import { BookView } from "@/components/yard/book";
import { CompaniesView } from "@/components/yard/companies";
import { BillsView } from "@/components/yard/bills";
import { SettingsView } from "@/components/yard/settings";

const AnalyticsView = lazy(() => import("@/components/yard/analytics"));

type View = "book" | "analyse" | "companies" | "bills" | "setup";

const NAV: Array<{ id: View; label: string; icon: typeof Cylinder }> = [
  { id: "book", label: "Book", icon: LayoutList },
  { id: "analyse", label: "Analyse", icon: PieChart },
  { id: "companies", label: "Firms", icon: Building2 },
  { id: "bills", label: "Bills", icon: Receipt },
  { id: "setup", label: "Setup", icon: Settings },
];

export function YardApp() {
  const [client] = useState(() => new QueryClient({ defaultOptions: { queries: { retry: 1 } } }));
  return (
    <QueryClientProvider client={client}>
      <Gate />
    </QueryClientProvider>
  );
}

function Gate() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) return <BootScreen label="Opening your yard…" />;
  if (!user) return <SignedOut />;
  return <Shell userId={user.id} />;
}

function BootScreen({ label }: { label: string }) {
  return (
    <main className="grid min-h-screen place-items-center bg-paper px-6 text-ink">
      <div className="max-w-sm text-center">
        <p className="font-display text-4xl">Cxyledge</p>
        <p className="mt-2 text-sm text-muted">{label}</p>
      </div>
    </main>
  );
}

function SignedOut() {
  return (
    <main className="grid min-h-screen place-items-center bg-paper px-6 text-ink">
      <div className="w-full max-w-sm">
        <div className="mb-6 flex items-center gap-3">
          <span className="grid size-11 place-items-center rounded-lg bg-ink text-paper">
            <Cylinder className="size-5" aria-hidden />
          </span>
          <p className="font-display text-3xl leading-none">Cxyledge</p>
        </div>
        <h1 className="font-display text-2xl">One yard book, every device</h1>
        <p className="mt-2 text-sm text-muted">
          Sign in to keep cylinders, payments, and bills in the cloud. A line entered on a phone updates the laptop, and the other way around.
        </p>
        <div className="mt-5">
          <SignInPanel />
        </div>
      </div>
    </main>
  );
}

function Shell({ userId }: { userId: string }) {
  const [view, setView] = useState<View>("book");
  const queryClient = useQueryClient();

  useEffect(() => {
    applyLook(readLook());
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => applyLook(readLook());
    media.addEventListener("change", onChange);
    return () => media.removeEventListener("change", onChange);
  }, []);

  const yardQuery = useQuery({
    queryKey: ["yard", userId],
    queryFn: () => getYard(),
    refetchInterval: 8000,
    refetchOnWindowFocus: true,
  });
  const entryQuery = useQuery({
    queryKey: ["entries", userId, yardQuery.data?.id],
    queryFn: () => listEntries(),
    enabled: Boolean(yardQuery.data?.id),
    refetchInterval: 5000,
    refetchOnWindowFocus: true,
  });
  const returnQuery = useQuery({
    queryKey: ["returns", userId, yardQuery.data?.id],
    queryFn: () => listReturns(),
    enabled: Boolean(yardQuery.data?.id),
    refetchInterval: 8000,
  });
  const docQuery = useQuery({
    queryKey: ["docs", userId, yardQuery.data?.id],
    queryFn: () => listDocuments(),
    enabled: Boolean(yardQuery.data?.id),
    refetchInterval: 8000,
  });

  const yard = yardQuery.data;
  const entries = entryQuery.data ?? [];
  const failed = yardQuery.isError || entryQuery.isError;
  const loading = yardQuery.isPending || (Boolean(yard) && entryQuery.isPending);

  function refresh() {
    void queryClient.invalidateQueries({ queryKey: ["yard", userId] });
    void queryClient.invalidateQueries({ queryKey: ["entries", userId] });
    void queryClient.invalidateQueries({ queryKey: ["returns", userId] });
    void queryClient.invalidateQueries({ queryKey: ["docs", userId] });
  }

  return (
    <div className="min-h-screen bg-paper text-ink">
      <header className="no-print sticky top-0 z-20 border-b border-line bg-card">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-3 px-4 py-3 lg:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <span className="grid size-11 shrink-0 place-items-center rounded-lg bg-ink text-paper">
              <Cylinder className="size-5" aria-hidden />
            </span>
            <div className="min-w-0">
              <p className="font-display text-xl leading-none">Cxyledge</p>
              <p className="truncate text-sm text-muted">{yard?.name ?? "Shared yard"}</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <p className="hidden text-right text-xs text-muted sm:block">
              Cloud book
              <span className="block">Updates on every signed-in device</span>
            </p>
            <UserButton />
          </div>
        </div>
      </header>

      <div className="mx-auto grid max-w-6xl lg:grid-cols-[13rem_minmax(0,1fr)]">
        <aside className="no-print hidden lg:block">
          <nav className="sticky top-20 flex flex-col gap-1 px-3 py-4" aria-label="Sections">
            {NAV.map((item) => {
              const Icon = item.icon;
              const on = view === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  aria-current={on ? "page" : undefined}
                  className={cn(
                    "flex h-11 items-center gap-2 rounded-lg px-3 text-left text-sm",
                    on ? "bg-sand font-semibold text-ink" : "text-muted hover:bg-sand",
                  )}
                  onClick={() => setView(item.id)}
                >
                  <Icon className="size-4" aria-hidden />
                  {item.label}
                </button>
              );
            })}
          </nav>
        </aside>
        <main className="min-w-0 px-4 py-5 pb-28 lg:px-8 lg:pb-16">
          {failed ? (
            <p className="mb-4 rounded-xl border border-line bg-sand px-4 py-3 text-sm text-rust" role="alert">
              The yard could not be loaded.{" "}
              <button type="button" className="font-semibold underline" onClick={refresh}>
                Try again
              </button>
            </p>
          ) : null}
          {loading ? <p className="text-sm text-muted">Loading the shared book…</p> : null}
          {!loading && yard && view === "book" ? (
            <BookView entries={entries} userId={userId} logs={returnQuery.data ?? []} onChanged={refresh} syncedAt={entryQuery.dataUpdatedAt} />
          ) : null}
          {!loading && view === "analyse" ? (
            <Suspense fallback={<p className="text-sm text-muted">Drawing the analysis…</p>}>
              <AnalyticsView entries={entries} yardName={yard?.name ?? "Cxyledge"} />
            </Suspense>
          ) : null}
          {!loading && view === "companies" ? (
            <CompaniesView entries={entries} documents={docQuery.data ?? []} onChanged={refresh} />
          ) : null}
          {!loading && yard && view === "bills" ? <BillsView yard={yard} entries={entries} onChanged={refresh} /> : null}
          {!loading && yard && view === "setup" ? <SettingsView yard={yard} onChanged={refresh} /> : null}
        </main>
      </div>

      <nav className="no-print fixed inset-x-0 bottom-0 z-30 border-t border-line bg-card lg:hidden" aria-label="Sections">
        <div className="mx-auto flex max-w-lg">
          {NAV.map((item) => {
            const Icon = item.icon;
            const on = view === item.id;
            return (
              <button
                key={item.id}
                type="button"
                aria-current={on ? "page" : undefined}
                className={cn(
                  "flex min-h-16 flex-1 flex-col items-center justify-center gap-0.5 text-xs",
                  on ? "font-semibold text-rust" : "text-muted",
                )}
                onClick={() => setView(item.id)}
              >
                <Icon className="size-5" aria-hidden />
                {item.label}
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
