import { useState } from "react";
import { movementsCsv, parseBook, summaryCsv, todayISO, type PersistedBook } from "@/lib/inventory/model";
import { useYard } from "@/lib/inventory/store";
import { Field, Panel } from "@/components/yard/ui";

function downloadText(filename: string, text: string, mime: string) {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

export function BackupView() {
  const yardName = useYard((s) => s.yardName);
  const types = useYard((s) => s.types);
  const movements = useYard((s) => s.movements);
  const sample = useYard((s) => s.sample);
  const setYardName = useYard((s) => s.setYardName);
  const clearAll = useYard((s) => s.clearAll);
  const loadSample = useYard((s) => s.loadSample);
  const importBook = useYard((s) => s.importBook);
  const [name, setName] = useState(yardName);
  const [armed, setArmed] = useState(false);
  const [error, setError] = useState("");
  const [pending, setPending] = useState<PersistedBook | null>(null);
  const [done, setDone] = useState("");

  const stamp = todayISO();

  function exportJson() {
    const book: PersistedBook = {
      version: 1,
      yardName,
      types,
      movements,
      sample: false,
      bannerHidden: true,
    };
    downloadText(`yardbook-${stamp}.json`, JSON.stringify(book, null, 2), "application/json");
    setDone("Backup file downloaded. Keep it wherever you keep your own files.");
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-3xl">On this device</h2>
        <p className="mt-1 max-w-xl text-sm text-muted">
          Yardbook does not upload counts, and there is no account. The book lives in this browser. Clearing site data, or switching browsers, starts empty unless you import a file you saved.
        </p>
      </div>

      <Panel title="Yard name">
        <form
          className="flex flex-col gap-3 sm:flex-row sm:items-end"
          onSubmit={(e) => {
            e.preventDefault();
            setYardName(name);
            setDone("Name saved on this device.");
          }}
        >
          <div className="flex-1">
            <Field label="Shown in the header">
              <input className="field" value={name} maxLength={60} onChange={(e) => setName(e.target.value)} />
            </Field>
          </div>
          <button type="submit" className="btn btn-pine">
            Save name
          </button>
        </form>
      </Panel>

      <Panel title="Backup file">
        <p className="text-sm text-muted">
          {types.length} types · {movements.length} entries
          {sample ? " · this is still the sample yard" : ""}. A JSON file can be loaded back. CSV is for a spreadsheet.
        </p>
        <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:flex-wrap">
          <button type="button" className="btn btn-rust" onClick={exportJson}>
            Download JSON
          </button>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              downloadText(`yardbook-entries-${stamp}.csv`, movementsCsv(types, movements), "text/csv");
              setDone("Entry list downloaded.");
            }}
          >
            Entries CSV
          </button>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              downloadText(`yardbook-days-${stamp}.csv`, summaryCsv(types, movements), "text/csv");
              setDone("Day summary downloaded.");
            }}
          >
            Day summary CSV
          </button>
        </div>
      </Panel>

      <Panel title="Restore a backup">
        <p className="text-sm text-muted">Replacing the book overwrites what is stored in this browser. Download a backup first if you might want it.</p>
        <input
          className="mt-3 block w-full text-sm"
          type="file"
          accept="application/json,.json"
          onChange={(e) => {
            const file = e.target.files?.[0];
            e.target.value = "";
            if (!file) return;
            const reader = new FileReader();
            reader.onload = () => {
              const parsed = parseBook(String(reader.result ?? ""));
              if (!parsed.ok) {
                setPending(null);
                setError(parsed.error);
                return;
              }
              setError("");
              setPending(parsed.data);
            };
            reader.readAsText(file);
          }}
        />
        {error ? (
          <p role="alert" className="mt-2 text-sm text-rust">
            {error}
          </p>
        ) : null}
        {pending ? (
          <div className="mt-3 rounded-lg bg-sand p-3">
            <p className="text-sm">
              Replace this browser’s book with <strong>{pending.yardName}</strong>, {pending.types.length} types and{" "}
              {pending.movements.length} entries?
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <button
                type="button"
                className="btn btn-rust"
                onClick={() => {
                  importBook(pending);
                  setName(pending.yardName);
                  setPending(null);
                  setDone("Backup loaded into this browser.");
                }}
              >
                Replace book
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setPending(null)}>
                Cancel
              </button>
            </div>
          </div>
        ) : null}
      </Panel>

      <Panel title="Example or erase">
        <div className="flex flex-col gap-2 sm:flex-row">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              loadSample();
              setName("Sample yard");
              setArmed(false);
              setDone("Sample yard loaded. It replaced whatever was in this browser.");
            }}
          >
            Load sample yard
          </button>
          {!armed ? (
            <button type="button" className="btn btn-ghost" onClick={() => setArmed(true)}>
              Erase this browser’s book
            </button>
          ) : (
            <>
              <button
                type="button"
                className="btn btn-rust"
                onClick={() => {
                  clearAll();
                  setName("My yard");
                  setArmed(false);
                  setPending(null);
                  setDone("Erased. This browser now has an empty yard.");
                }}
              >
                Yes, erase everything
              </button>
              <button type="button" className="btn btn-ghost" onClick={() => setArmed(false)}>
                Cancel
              </button>
            </>
          )}
        </div>
      </Panel>
      {done ? (
        <p role="status" className="text-sm text-pine">
          {done}
        </p>
      ) : null}
    </div>
  );
}
