import { useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Trash2 } from "lucide-react";
import {
  createEntry,
  deleteEntry,
  parseEntry,
  seedSample,
  updateEntry,
  type Entry,
  type EntryDraft,
  type PaymentStatus,
  type ReturnLog,
} from "@/lib/inventory/api";
import { companyBalances, movementLabel, paymentLabel } from "@/lib/inventory/analyse";
import { formatDay } from "@/lib/inventory/model";
import { cylinderTypeOptions, rupee, splitSerials, subtotal } from "@/lib/inventory/serials";
import { cn } from "@/lib/cn";
import { Field, Panel, Stat } from "@/components/yard/ui";
import { ReturnDesk } from "@/components/yard/return-desk";

const PAYMENTS: Array<{ id: PaymentStatus; label: string }> = [
  { id: "received", label: "Received" },
  { id: "partial", label: "Part received" },
  { id: "unpaid", label: "Not received" },
];

function todayISO() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function blankDraft(): EntryDraft {
  return {
    companyName: "",
    entryDate: todayISO(),
    serialNo: "",
    quantity: 0,
    paymentStatus: "unpaid",
    amountDue: null,
    amountPaid: null,
    note: "",
    movement: "delivery",
    unitPrice: null,
    billNo: "",
    parentId: null,
    qtyOverride: false,
    cylinderType: "",
  };
}

export function BookView({
  entries,
  userId,
  logs,
  onChanged,
  syncedAt,
}: {
  entries: Entry[];
  userId: string;
  logs: ReturnLog[];
  onChanged: () => void;
  syncedAt: number;
}) {
  const [open, setOpen] = useState(entries.length === 0);
  const [draft, setDraft] = useState<EntryDraft>(blankDraft);
  const [editing, setEditing] = useState<string | null>(null);
  const [finalTouched, setFinalTouched] = useState(false);
  const [error, setError] = useState("");
  const [filter, setFilter] = useState<PaymentStatus | "all">("all");
  const [query, setQuery] = useState("");
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);

  const save = useMutation({
    mutationFn: async () => {
      const parsed = parseEntry(draft);
      if (!parsed.ok) return parsed;
      if (editing) return updateEntry({ data: { ...parsed.value, id: editing } });
      return createEntry({ data: parsed.value });
    },
    onSuccess: (result) => {
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setError("");
      setDraft(blankDraft());
      setEditing(null);
      setFinalTouched(false);
      setOpen(false);
      onChanged();
    },
    onError: () => setError("Could not save. Check that you are still signed in."),
  });

  const remove = useMutation({
    mutationFn: (id: string) => deleteEntry({ data: id }),
    onSuccess: () => {
      setPendingDelete(null);
      onChanged();
    },
  });

  const sample = useMutation({
    mutationFn: () => seedSample(),
    onSuccess: (result) => {
      if (!result.ok) {
        setError(result.error);
        return;
      }
      onChanged();
    },
  });

  const balances = useMemo(() => companyBalances(entries), [entries]);
  const stillOut = balances.reduce((total, row) => total + row.outstandingQty, 0);
  const toCollect = balances.reduce((total, row) => total + row.toCollect, 0);
  const names = useMemo(() => [...new Set(entries.map((entry) => entry.companyName))].sort(), [entries]);
  const typeOptions = useMemo(() => cylinderTypeOptions(entries.map((entry) => entry.cylinderType)), [entries]);
  const liveBalance = balances.find((row) => row.company.toLowerCase() === draft.companyName.trim().toLowerCase());
  const counted = splitSerials(draft.serialNo).length;
  const lineSubtotal = subtotal(draft.quantity, draft.unitPrice);

  const shown = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return entries.filter((entry) => {
      if (filter !== "all" && entry.paymentStatus !== filter) return false;
      if (!needle) return true;
      return [entry.companyName, entry.serialNo, entry.note, entry.billNo, entry.movement, paymentLabel(entry.paymentStatus)]
        .join(" ")
        .toLowerCase()
        .includes(needle);
    });
  }, [entries, filter, query]);

  const synced = syncedAt ? new Date(syncedAt).toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit" }) : "";

  function applySerials(serialNo: string, base: EntryDraft, touched: boolean): EntryDraft {
    const nextCount = splitSerials(serialNo).length;
    const quantity = base.qtyOverride ? base.quantity : nextCount;
    const amountDue = touched ? base.amountDue : subtotal(quantity, base.unitPrice);
    return { ...base, serialNo, quantity, amountDue };
  }

  function edit(entry: Entry) {
    const serialCount = splitSerials(entry.serialNo).length;
    setEditing(entry.id);
    setFinalTouched(entry.unitPrice != null && entry.amountDue !== subtotal(entry.quantity, entry.unitPrice));
    setDraft({
      companyName: entry.companyName,
      entryDate: entry.entryDate,
      serialNo: entry.serialNo,
      quantity: entry.quantity,
      paymentStatus: entry.paymentStatus,
      amountDue: entry.amountDue,
      amountPaid: entry.amountPaid,
      note: entry.note,
      movement: entry.movement === "return" ? "return" : entry.movement,
      unitPrice: entry.unitPrice,
      billNo: entry.billNo,
      parentId: entry.parentId,
      qtyOverride: serialCount !== entry.quantity,
      cylinderType: entry.cylinderType,
    });
    setOpen(true);
    setError("");
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h2 className="font-display text-3xl">Cylinder book</h2>
          <p className="mt-1 text-sm text-muted">
            {entries.length} {entries.length === 1 ? "line" : "lines"}
            {synced ? ` · synced ${synced}` : ""}. A new line on any signed-in phone or computer shows up here.
          </p>
        </div>
        <button
          type="button"
          className="btn btn-rust"
          onClick={() => {
            setOpen(true);
            if (!editing) {
              setDraft(blankDraft());
              setFinalTouched(false);
            }
          }}
        >
          Add entry
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Stat label="Still with customers" value={stillOut} tone="rust" />
        <Stat label="To collect" value={rupee(toCollect, 0)} tone="pine" />
      </div>

      {open ? (
        <Panel title={editing ? "Edit entry" : "New entry"}>
          <form
            className="grid gap-3 sm:grid-cols-2"
            onSubmit={(event) => {
              event.preventDefault();
              setError("");
              save.mutate();
            }}
          >
            <Field label="Company name">
              <input
                className="field"
                value={draft.companyName}
                list="company-names"
                onChange={(event) => setDraft({ ...draft, companyName: event.target.value })}
                placeholder="Sharma Stores"
                required
              />
              <datalist id="company-names">
                {names.map((name) => (
                  <option key={name} value={name} />
                ))}
              </datalist>
            </Field>
            <Field label="Date">
              <input
                type="date"
                className="field"
                value={draft.entryDate}
                onChange={(event) => setDraft({ ...draft, entryDate: event.target.value })}
                required
              />
            </Field>
            <div className="sm:col-span-2">
              <div className="grid grid-cols-2 gap-2">
                {(["delivery", "purchase"] as const).map((movement) => (
                  <button
                    key={movement}
                    type="button"
                    className={cn("btn", draft.movement === movement ? "btn-pine" : "btn-ghost")}
                    onClick={() => setDraft({ ...draft, movement })}
                  >
                    {movement === "delivery" ? "Delivery" : "Purchase"}
                  </button>
                ))}
              </div>
              <p className="mt-1 text-xs text-muted">
                {draft.movement === "purchase"
                  ? "A purchase is stock you bought. It does not add cylinders sitting at a customer."
                  : "A delivery is cylinders sent out. They stay on that company's balance until returned."}
              </p>
            </div>
            <div className="sm:col-span-2">
              <Field label="Cylinder type" hint="Pick one or type your own, e.g. Oxygen 47L.">
                <input
                  className="field"
                  value={draft.cylinderType}
                  list="cylinder-types"
                  onChange={(event) => setDraft({ ...draft, cylinderType: event.target.value })}
                  placeholder="Oxygen 47L"
                />
                <datalist id="cylinder-types">
                  {typeOptions.map((name) => (
                    <option key={name} value={name} />
                  ))}
                </datalist>
              </Field>
            </div>
            <div className="sm:col-span-2">
              <Field label="Cylinder serial no." hint={counted ? `${counted} unique serial${counted === 1 ? "" : "s"} counted.` : "One per line, or separated by commas."}>
                <textarea
                  className="field field-area min-h-24"
                  value={draft.serialNo}
                  onChange={(event) => setDraft(applySerials(event.target.value, draft, finalTouched))}
                  placeholder={"S-44101\nS-44102"}
                />
              </Field>
            </div>
            <Field label="No. of cylinders" hint={draft.qtyOverride ? "Manual count." : "Locked to the serial count."}>
              <input
                className={cn("field tabular-nums", !draft.qtyOverride && "bg-sand")}
                inputMode="numeric"
                readOnly={!draft.qtyOverride}
                value={String(draft.quantity)}
                onChange={(event) => {
                  const quantity = Number(event.target.value.replace(/[^\d]/g, "") || "0");
                  setDraft({
                    ...draft,
                    quantity,
                    amountDue: finalTouched ? draft.amountDue : subtotal(quantity, draft.unitPrice),
                  });
                }}
              />
            </Field>
            <div className="flex items-end">
              <button
                type="button"
                role="switch"
                aria-checked={draft.qtyOverride}
                className="btn btn-ghost w-full justify-between"
                onClick={() => {
                  const qtyOverride = !draft.qtyOverride;
                  const quantity = qtyOverride ? draft.quantity || counted || 1 : counted;
                  setDraft({
                    ...draft,
                    qtyOverride,
                    quantity,
                    amountDue: finalTouched ? draft.amountDue : subtotal(quantity, draft.unitPrice),
                  });
                }}
              >
                Override quantity
                <span className={cn("inline-flex h-7 w-12 items-center rounded-full p-1", draft.qtyOverride ? "bg-pine" : "bg-line")}>
                  <span className={cn("size-5 rounded-full bg-card", draft.qtyOverride && "ml-auto")} />
                </span>
              </button>
            </div>
            <Field label="Price per cylinder (₹)">
              <input
                className="field tabular-nums"
                inputMode="decimal"
                value={draft.unitPrice ?? ""}
                placeholder="0"
                onChange={(event) => {
                  const unitPrice = moneyInput(event.target.value);
                  setDraft({
                    ...draft,
                    unitPrice,
                    amountDue: finalTouched ? draft.amountDue : subtotal(draft.quantity, unitPrice),
                  });
                }}
              />
            </Field>
            <div className="rounded-xl border border-line bg-sand px-4 py-3 text-sm">
              <p>Subtotal {rupee(lineSubtotal)}</p>
              <p className="text-muted">Quantity × price. Final amount can differ if you add a round-off.</p>
            </div>
            <fieldset className="sm:col-span-2">
              <legend className="mb-1.5 text-sm font-medium">Payment</legend>
              <div className="grid grid-cols-3 gap-2">
                {PAYMENTS.map((payment) => (
                  <button
                    key={payment.id}
                    type="button"
                    className={cn("btn px-2 text-xs sm:text-sm", draft.paymentStatus === payment.id ? "btn-pine" : "btn-ghost")}
                    onClick={() =>
                      setDraft({
                        ...draft,
                        paymentStatus: payment.id,
                        amountPaid:
                          payment.id === "received" && draft.amountPaid == null ? draft.amountDue : draft.amountPaid,
                      })
                    }
                  >
                    {payment.label}
                  </button>
                ))}
              </div>
            </fieldset>
            <Field label="Final amount (₹)">
              <input
                className="field tabular-nums"
                inputMode="decimal"
                value={draft.amountDue ?? ""}
                placeholder="0"
                onChange={(event) => {
                  setFinalTouched(true);
                  setDraft({ ...draft, amountDue: moneyInput(event.target.value) });
                }}
              />
            </Field>
            <Field label="Amount received (₹)">
              <input
                className="field tabular-nums"
                inputMode="decimal"
                value={draft.amountPaid ?? ""}
                placeholder="0"
                onChange={(event) => setDraft({ ...draft, amountPaid: moneyInput(event.target.value) })}
              />
            </Field>
            <Field label="Bill no.">
              <input className="field" value={draft.billNo} maxLength={40} onChange={(event) => setDraft({ ...draft, billNo: event.target.value })} />
            </Field>
            <Field label="Note">
              <input className="field" value={draft.note} maxLength={300} onChange={(event) => setDraft({ ...draft, note: event.target.value })} />
            </Field>
            {liveBalance ? (
              <div className="rounded-xl border border-line bg-card px-4 py-3 text-sm sm:col-span-2">
                <p className="font-medium">{liveBalance.company} balance</p>
                <p className="mt-1 text-muted">
                  {liveBalance.outstandingQty} cylinders still out
                  {liveBalance.outstandingSerials.length ? ` · ${liveBalance.outstandingSerials.slice(0, 6).join(", ")}` : ""}
                  {liveBalance.outstandingSerials.length > 6 ? "…" : ""}. To collect {rupee(liveBalance.toCollect, 0)}.
                </p>
              </div>
            ) : null}
            {error ? (
              <p role="alert" className="text-sm text-rust sm:col-span-2">
                {error}
              </p>
            ) : null}
            <div className="flex flex-wrap gap-2 sm:col-span-2">
              <button type="submit" className="btn btn-rust" disabled={save.isPending}>
                {save.isPending ? "Saving…" : editing ? "Save changes" : "Add to the book"}
              </button>
              <button
                type="button"
                className="btn btn-ghost"
                onClick={() => {
                  setOpen(false);
                  setEditing(null);
                  setDraft(blankDraft());
                  setFinalTouched(false);
                  setError("");
                }}
              >
                Cancel
              </button>
            </div>
          </form>
        </Panel>
      ) : null}

      <div className="flex flex-col gap-2 sm:flex-row sm:items-center">
        <input
          className="field sm:max-w-xs"
          value={query}
          onChange={(event) => setQuery(event.target.value)}
          placeholder="Search company, serial, or bill"
          aria-label="Search entries"
        />
        <div className="flex flex-wrap gap-2">
          {(["all", "unpaid", "partial", "received"] as const).map((id) => (
            <button key={id} type="button" className={cn("btn px-3 text-sm", filter === id ? "btn-pine" : "btn-ghost")} onClick={() => setFilter(id)}>
              {id === "all" ? "All" : PAYMENTS.find((payment) => payment.id === id)?.label}
            </button>
          ))}
        </div>
      </div>

      {shown.length === 0 ? (
        <div className="rounded-xl border border-dashed border-line bg-card px-4 py-8 text-center">
          <p className="text-sm text-muted">
            {entries.length === 0
              ? "No cylinders booked yet. Add a company, serials, a price, and whether payment was received."
              : "Nothing matches that filter."}
          </p>
          {entries.length === 0 ? (
            <button type="button" className="btn btn-ghost mt-4" disabled={sample.isPending} onClick={() => sample.mutate()}>
              {sample.isPending ? "Adding…" : "Add a sample week"}
            </button>
          ) : null}
        </div>
      ) : (
        <ul className="flex flex-col gap-3">
          {shown.map((entry) => (
            <li key={entry.id} className="rounded-xl border border-line bg-card p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h3 className="font-display text-xl leading-tight">{entry.companyName}</h3>
                  <p className="mt-1 text-sm text-muted">
                    {formatDay(entry.entryDate)} · {movementLabel(entry.movement)} · {entry.quantity}{" "}
                    {entry.quantity === 1 ? "cylinder" : "cylinders"}
                    {entry.cylinderType ? ` · ${entry.cylinderType}` : ""}
                    {entry.createdBy === userId ? " · you" : " · teammate"}
                  </p>
                </div>
                <span className={cn("shrink-0 rounded-full px-2.5 py-1 text-xs font-semibold", entry.paymentStatus === "received" ? "bg-pine text-pine-fg" : "bg-sand text-rust")}>
                  {paymentLabel(entry.paymentStatus)}
                </span>
              </div>
              {entry.serialNo ? <p className="mt-3 whitespace-pre-wrap text-sm">Serial {entry.serialNo}</p> : null}
              <p className="mt-2 text-sm tabular-nums text-muted">
                {entry.unitPrice != null ? `Price ${rupee(entry.unitPrice)} · ` : ""}
                Due {rupee(entry.amountDue)} · Received {rupee(entry.amountPaid)}
                {entry.billNo ? ` · ${entry.billNo}` : ""}
              </p>
              {entry.note ? <p className="mt-2 text-sm">{entry.note}</p> : null}
              <div className="mt-3 flex flex-wrap gap-2">
                <button type="button" className="btn btn-ghost" onClick={() => edit(entry)}>
                  Edit
                </button>
                {pendingDelete === entry.id ? (
                  <>
                    <button type="button" className="btn btn-rust" onClick={() => remove.mutate(entry.id)} disabled={remove.isPending}>
                      Delete
                    </button>
                    <button type="button" className="btn btn-ghost" onClick={() => setPendingDelete(null)}>
                      Keep
                    </button>
                  </>
                ) : (
                  <button type="button" className="btn btn-ghost size-11 px-0" aria-label={`Delete ${entry.companyName}`} onClick={() => setPendingDelete(entry.id)}>
                    <Trash2 className="size-4" aria-hidden />
                  </button>
                )}
              </div>
            </li>
          ))}
        </ul>
      )}

      <ReturnDesk entries={entries} logs={logs} userId={userId} onChanged={onChanged} />
    </div>
  );
}

function moneyInput(raw: string): number | null {
  const cleaned = raw.replace(/[^\d.]/g, "");
  if (!cleaned) return null;
  const value = Number(cleaned);
  return Number.isFinite(value) ? value : null;
}
