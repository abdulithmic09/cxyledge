import { useMemo, useState } from "react";
import {
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import {
  addDays,
  correctionTotals,
  formatCover,
  formatDay,
  formatDelta,
  partyStats,
  runningByDay,
  thinSeries,
  todayISO,
  typeStats,
} from "@/lib/inventory/model";
import { useYard } from "@/lib/inventory/store";
import { cn } from "@/lib/cn";
import { EmptyNote, Panel } from "@/components/yard/ui";

const PERIODS = [
  { id: 7, label: "7 days" },
  { id: 30, label: "30 days" },
  { id: 90, label: "90 days" },
  { id: 0, label: "All" },
] as const;

type TipPayload = { name?: string; value?: number | string };

function Tip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: TipPayload[];
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-line bg-card px-3 py-2 text-sm">
      <p className="font-medium">{label}</p>
      {payload.map((p) => (
        <p key={String(p.name)} className="tabular-nums text-muted">
          {p.name}: {p.value}
        </p>
      ))}
    </div>
  );
}

export default function TrendsView() {
  const types = useYard((s) => s.types);
  const movements = useYard((s) => s.movements);
  const [period, setPeriod] = useState<(typeof PERIODS)[number]["id"]>(30);
  const today = todayISO();

  const range = useMemo(() => {
    if (movements.length === 0) return { from: today, to: today };
    const dates = movements.map((m) => m.date).sort();
    const earliest = dates[0] ?? today;
    const from = period === 0 ? earliest : addDays(today, -(period - 1));
    return { from: from < earliest ? earliest : from, to: today };
  }, [movements, period, today]);

  const series = useMemo(
    () => runningByDay(movements, range.from, range.to),
    [movements, range.from, range.to],
  );
  const chart = useMemo(() => thinSeries(series), [series]);
  const stats = useMemo(
    () => typeStats(types, movements, range.from, range.to, today),
    [types, movements, range.from, range.to, today],
  );
  const parties = useMemo(
    () => partyStats(movements, range.from, range.to).slice(0, 8),
    [movements, range.from, range.to],
  );
  const corrections = useMemo(
    () => correctionTotals(movements, range.from, range.to),
    [movements, range.from, range.to],
  );

  if (movements.length === 0) {
    return (
      <EmptyNote title="Nothing to analyse yet">
        Once a few days are in the book, this page shows issue pace, stock cover, and who is taking cylinders.
      </EmptyNote>
    );
  }

  const issued = series.reduce((a, p) => a + p.issued, 0);
  const received = series.reduce((a, p) => a + p.received, 0);
  const net = received - issued;
  const busiest = series.reduce<(typeof series)[number] | null>(
    (best, p) => (!best || p.issued > best.issued ? p : best),
    null,
  );
  const tight = stats
    .filter((s) => !s.type.archived && s.avgIssue > 0)
    .sort((a, b) => a.full / a.avgIssue - b.full / b.avgIssue)[0];
  const lows = stats.filter((s) => !s.type.archived && s.full <= s.type.lowFull);

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="font-display text-3xl">Trends</h2>
          <p className="mt-1 text-sm text-muted">
            {formatDay(range.from)} – {formatDay(range.to)}
          </p>
        </div>
        <div className="grid grid-cols-4 gap-2">
          {PERIODS.map((p) => (
            <button
              key={p.id}
              type="button"
              className={cn("btn px-1 text-xs sm:px-3 sm:text-sm", period === p.id ? "btn-pine" : "btn-ghost")}
              onClick={() => setPeriod(p.id)}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>

      <Panel>
        <p className="text-sm leading-relaxed">
          Issued <strong className="tabular-nums">{issued}</strong> full and received{" "}
          <strong className="tabular-nums">{received}</strong>.{" "}
          {issued === 0 && received === 0
            ? "No full cylinders moved in this stretch."
            : net >= 0
              ? `${net} more came in than went out.`
              : `${-net} more went out than came in.`}
          {busiest && busiest.issued > 0 ? ` Busiest issue day was ${formatDay(busiest.date)} (${busiest.issued}).` : ""}
        </p>
        {tight ? (
          <p className="mt-2 text-sm text-muted">
            Tightest cover: {tight.type.name}, {formatCover(tight.full, tight.avgIssue).toLowerCase()}.
          </p>
        ) : null}
        {lows.length > 0 ? (
          <ul className="mt-3 flex flex-col gap-1 text-sm text-rust">
            {lows.map((s) => (
              <li key={s.type.id}>
                {s.type.name} is at {s.full} full, at or under the {s.type.lowFull} alert.
              </li>
            ))}
          </ul>
        ) : (
          <p className="mt-2 text-sm text-pine">No type is under its full-cylinder alert.</p>
        )}
        {corrections.count > 0 ? (
          <p className="mt-2 text-sm text-muted">
            Count corrections, excluding opening balances: full {formatDelta(corrections.full)}, empty{" "}
            {formatDelta(corrections.empty)}.
          </p>
        ) : null}
      </Panel>

      <Panel title="Full cylinders moved">
        <div className="h-64 w-full min-w-0">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={chart} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="var(--color-line)" vertical={false} />
              <XAxis
                dataKey="label"
                tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                interval="preserveStartEnd"
              />
              <YAxis
                tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                width={32}
                allowDecimals={false}
              />
              <Tooltip content={<Tip />} cursor={{ fill: "var(--color-sand)" }} />
              <Bar dataKey="issued" name="Issued" fill="var(--color-rust)" radius={[4, 4, 0, 0]} maxBarSize={22} />
              <Bar dataKey="received" name="Received" fill="var(--color-pine)" radius={[4, 4, 0, 0]} maxBarSize={22} />
            </BarChart>
          </ResponsiveContainer>
        </div>
        <p className="mt-2 flex gap-4 text-xs text-muted">
          <span className="inline-flex items-center gap-1">
            <i className="inline-block size-2 rounded-full bg-rust" /> Issued
          </span>
          <span className="inline-flex items-center gap-1">
            <i className="inline-block size-2 rounded-full bg-pine" /> Received
          </span>
        </p>
      </Panel>

      <Panel title="Stock at close of day">
        <div className="h-64 w-full min-w-0">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chart} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="var(--color-line)" vertical={false} />
              <XAxis
                dataKey="label"
                tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                interval="preserveStartEnd"
              />
              <YAxis
                tick={{ fill: "var(--color-muted)", fontSize: 12 }}
                axisLine={false}
                tickLine={false}
                width={32}
                allowDecimals={false}
              />
              <Tooltip content={<Tip />} />
              <Line type="monotone" dataKey="fullClose" name="Full" stroke="var(--color-pine)" strokeWidth={2} dot={false} />
              <Line
                type="monotone"
                dataKey="emptyClose"
                name="Empty"
                stroke="var(--color-rust)"
                strokeWidth={2}
                dot={false}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
        <p className="mt-2 flex gap-4 text-xs text-muted">
          <span className="inline-flex items-center gap-1">
            <i className="inline-block size-2 rounded-full bg-pine" /> Full on hand
          </span>
          <span className="inline-flex items-center gap-1">
            <i className="inline-block size-2 rounded-full bg-rust" /> Empty on hand
          </span>
        </p>
      </Panel>

      <Panel title="By type">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[36rem] text-left text-sm">
            <thead className="text-muted">
              <tr className="border-b border-line">
                <th className="py-2 pr-3 font-medium">Type</th>
                <th className="py-2 pr-3 font-medium">Full now</th>
                <th className="py-2 pr-3 font-medium">Empty</th>
                <th className="py-2 pr-3 font-medium">Issued</th>
                <th className="py-2 pr-3 font-medium">Received</th>
                <th className="py-2 font-medium">Cover</th>
              </tr>
            </thead>
            <tbody>
              {stats.map((s) => (
                <tr key={s.type.id} className="border-b border-line last:border-0">
                  <td className="py-2 pr-3">
                    <span className="font-medium">{s.type.name}</span>
                    {s.type.size ? <span className="block text-xs text-muted">{s.type.size}</span> : null}
                  </td>
                  <td className="py-2 pr-3 tabular-nums text-pine">{s.full}</td>
                  <td className="py-2 pr-3 tabular-nums">{s.empty}</td>
                  <td className="py-2 pr-3 tabular-nums">{s.issued}</td>
                  <td className="py-2 pr-3 tabular-nums">{s.received}</td>
                  <td className="py-2 text-muted">{formatCover(s.full, s.avgIssue)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-muted">Cover divides full on hand by average daily issues in the selected stretch.</p>
      </Panel>

      <Panel title="Who took full cylinders">
        {parties.length === 0 ? (
          <p className="text-sm text-muted">No customer names on issues in this stretch.</p>
        ) : (
          <ul className="divide-y divide-line">
            {parties.map((p) => (
              <li key={p.party} className="flex items-baseline justify-between gap-3 py-2 text-sm">
                <span className="min-w-0 truncate font-medium">{p.party}</span>
                <span className="shrink-0 tabular-nums text-muted">
                  {p.issued} issued
                  {p.collected ? ` · ${p.collected} empties back` : ""}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Panel>
    </div>
  );
}
