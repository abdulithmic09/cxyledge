import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { deleteDocument, listCompanyMeta, saveCompanyMeta, saveDocument, type DocRecord, type Entry } from "@/lib/inventory/api";
import { companyBalances, movementLabel, paymentLabel } from "@/lib/inventory/analyse";
import { formatDay } from "@/lib/inventory/model";
import { downloadBlob, makePdf, shareBlob, toCsv } from "@/lib/inventory/files";
import { rupee } from "@/lib/inventory/serials";
import { ExportBar } from "@/components/yard/export-bar";
import { Field, Panel } from "@/components/yard/ui";

export function CompaniesView({
  entries,
  documents,
  onChanged,
}: {
  entries: Entry[];
  documents: DocRecord[];
  onChanged: () => void;
}) {
  const [query, setQuery] = useState("");
  const [selected, setSelected] = useState<string | null>(null);
  const [error, setError] = useState("");
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const balances = useMemo(() => companyBalances(entries), [entries]);
  const queryClient = useQueryClient();
  const metaQuery = useQuery({ queryKey: ["company-meta"], queryFn: () => listCompanyMeta() });
  const metaByName = useMemo(() => new Map((metaQuery.data ?? []).map((row) => [row.companyName, row])), [metaQuery.data]);
  const [keywords, setKeywords] = useState("");
  const [notes, setNotes] = useState("");
  const [metaState, setMetaState] = useState("");

  const visible = useMemo(() => {
    const needle = query.trim().toLowerCase();
    if (!needle) return balances;
    return balances.filter((row) => {
      const entryText = entries
        .filter((entry) => entry.companyName === row.company)
        .map((entry) => [entry.entryDate, entry.serialNo, entry.billNo, entry.note, entry.paymentStatus, entry.movement].join(" "))
        .join(" ");
      const docText = documents
        .filter((doc) => doc.companyName === row.company)
        .map((doc) => doc.title)
        .join(" ");
      const meta = metaByName.get(row.company);
      const metaText = meta ? `${meta.keywords} ${meta.notes}` : "";
      const typeText = entries
        .filter((entry) => entry.companyName === row.company)
        .map((entry) => entry.cylinderType)
        .join(" ");
      return `${row.company} ${entryText} ${docText} ${metaText} ${typeText}`.toLowerCase().includes(needle);
    });
  }, [balances, documents, entries, query, metaByName]);

  const company = selected && visible.some((row) => row.company === selected) ? selected : (visible[0]?.company ?? null);
  const balance = balances.find((row) => row.company === company);
  const companyEntries = entries.filter((entry) => entry.companyName === company);
  const companyDocs = documents.filter((doc) => doc.companyName === company);
  const companyMeta = company ? metaByName.get(company) : undefined;

  useEffect(() => {
    setKeywords(companyMeta?.keywords ?? "");
    setNotes(companyMeta?.notes ?? "");
    setMetaState("");
  }, [company, companyMeta?.keywords, companyMeta?.notes]);

  async function onSaveMeta() {
    if (!company) return;
    setMetaState("Saving…");
    const result = await saveCompanyMeta({ data: { companyName: company, keywords, notes } });
    if (!result.ok) {
      setMetaState(result.error);
      return;
    }
    await queryClient.invalidateQueries({ queryKey: ["company-meta"] });
    setMetaState("Saved");
  }

  const lines = balance
    ? [
        balance.company,
        `Still out ${balance.outstandingQty}`,
        `Serials ${balance.outstandingSerials.join(", ") || "none"}`,
        ...balance.byType.map((row) => `  ${row.type}: ${row.out} out`),
        `To collect ${rupee(balance.toCollect)}`,
        `To pay ${rupee(balance.toPay)}`,
        `Delivered ${balance.delivered} · Returned ${balance.returned} · Purchased ${balance.purchased}`,
        "",
        ...companyEntries.map(
          (entry) =>
            `${entry.entryDate}  ${movementLabel(entry.movement)}  ${entry.quantity}  ${entry.serialNo.replace(/\n/g, " ")}  ${entry.billNo}  ${paymentLabel(entry.paymentStatus)}  ${rupee(entry.amountDue)}`,
        ),
      ]
    : [];
  const csv = toCsv(
    ["Date", "Movement", "Cylinder type", "Qty", "Serials", "Bill", "Payment", "Due", "Paid"],
    companyEntries.map((entry) => [
      entry.entryDate,
      movementLabel(entry.movement),
      entry.cylinderType,
      String(entry.quantity),
      entry.serialNo.replace(/\n/g, " "),
      entry.billNo,
      paymentLabel(entry.paymentStatus),
      entry.amountDue == null ? "" : String(entry.amountDue),
      entry.amountPaid == null ? "" : String(entry.amountPaid),
    ]),
  );

  async function onUpload(file: File | undefined) {
    if (!file || !company) return;
    setError("");
    if (file.size > 280_000) {
      setError("Keep each file under 280 KB.");
      return;
    }
    const content = await readFile(file);
    const result = await saveDocument({
      data: { companyName: company, title: file.name, kind: "upload", mime: file.type || "application/octet-stream", content },
    });
    if (!result.ok) {
      setError(result.error);
      return;
    }
    onChanged();
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-3xl">Companies</h2>
        <p className="mt-1 text-sm text-muted">Search names, keywords, notes, serials, bills, and dates. Each company keeps its own file folder.</p>
      </div>
      <input className="field" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Search companies, keywords, serials, bills, dates" aria-label="Search companies" />
      {visible.length === 0 ? (
        <Panel title={entries.length === 0 ? "No companies yet" : "No match"}>
          <p className="text-sm text-muted">{entries.length === 0 ? "Companies appear as soon as you book a delivery or a bill." : "Try a serial number, a bill number, or part of the name."}</p>
        </Panel>
      ) : (
        <div className="grid gap-4 lg:grid-cols-[16rem_minmax(0,1fr)]">
          <ul className="flex flex-col gap-2">
            {visible.map((row) => (
              <li key={row.company}>
                <button
                  type="button"
                  className={row.company === company ? "btn btn-pine h-auto w-full flex-col items-start py-3" : "btn btn-ghost h-auto w-full flex-col items-start py-3"}
                  onClick={() => setSelected(row.company)}
                >
                  <span>{row.company}</span>
                  <span className="text-xs font-normal opacity-80">{row.outstandingQty} out · {rupee(row.toCollect, 0)}</span>
                </button>
              </li>
            ))}
          </ul>
          {balance ? (
            <div className="flex flex-col gap-4">
              <Panel title={balance.company}>
                <p className="text-sm text-muted">
                  Last updated{" "}
                  {balance.lastUpdated
                    ? new Date(balance.lastUpdated).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })
                    : "—"}
                </p>
                <div className="mt-3 grid grid-cols-2 gap-3 text-sm">
                  <p>
                    <span className="block text-muted">Still out</span>
                    <span className="text-2xl font-semibold tabular-nums">{balance.outstandingQty}</span>
                  </p>
                  <p>
                    <span className="block text-muted">To collect</span>
                    <span className="text-2xl font-semibold tabular-nums">{rupee(balance.toCollect, 0)}</span>
                  </p>
                </div>
                {balance.byType.length ? (
                  <div className="mt-3 overflow-hidden rounded-lg border border-line">
                    <table className="w-full text-sm">
                      <thead className="bg-sand text-left text-xs text-muted">
                        <tr>
                          <th className="px-3 py-2 font-semibold">Cylinder type</th>
                          <th className="px-3 py-2 text-right font-semibold">At customer</th>
                        </tr>
                      </thead>
                      <tbody>
                        {balance.byType.map((row) => (
                          <tr key={row.type} className="border-t border-line">
                            <td className="px-3 py-2">{row.type}</td>
                            <td className="px-3 py-2 text-right tabular-nums">{row.out}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : null}
                <p className="mt-3 text-sm">
                  {balance.outstandingSerials.length ? balance.outstandingSerials.join(", ") : "No serials are still out."}
                </p>
                <p className="mt-2 text-sm text-muted">
                  Delivered {balance.delivered} · returned {balance.returned} · purchased {balance.purchased} · to pay {rupee(balance.toPay, 0)}
                </p>
              </Panel>
              <Panel title="Keywords & notes">
                <div className="grid gap-3">
                  <Field label="Keywords" hint="Words you might search by: area, industry, contact person.">
                    <input className="field" value={keywords} maxLength={300} onChange={(event) => setKeywords(event.target.value)} placeholder="hospital, Bhosari, welding" />
                  </Field>
                  <Field label="Notes">
                    <textarea className="field field-area min-h-20" value={notes} maxLength={1000} onChange={(event) => setNotes(event.target.value)} placeholder="Billing contact, credit terms, delivery timings" />
                  </Field>
                  <div className="flex items-center gap-3">
                    <button type="button" className="btn btn-pine" onClick={() => void onSaveMeta()}>
                      Save
                    </button>
                    {metaState ? <span className="text-sm text-muted">{metaState}</span> : null}
                  </div>
                </div>
              </Panel>
              <Panel title="Files">
                <Field label="Upload a bill, photo, or PDF" hint="Stored in this account and visible on every signed-in device. 280 KB each.">
                  <input
                    className="field py-2"
                    type="file"
                    accept="application/pdf,image/png,image/jpeg,image/webp,text/plain,text/csv"
                    onChange={(event) => {
                      void onUpload(event.target.files?.[0]);
                      event.target.value = "";
                    }}
                  />
                </Field>
                {error ? <p className="mt-2 text-sm text-rust">{error}</p> : null}
                {companyDocs.length === 0 ? (
                  <p className="mt-3 text-sm text-muted">No files for this company yet. Saved bills land here too.</p>
                ) : (
                  <ul className="mt-3 flex flex-col gap-2">
                    {companyDocs.map((doc) => (
                      <li key={doc.id} className="rounded-lg border border-line px-3 py-3">
                        <p className="text-sm font-medium">{doc.title}</p>
                        <p className="text-xs text-muted">
                          {doc.kind} · {new Date(doc.createdAt).toLocaleDateString("en-IN")}
                        </p>
                        <div className="mt-2 flex flex-wrap gap-2">
                          <button type="button" className="btn btn-ghost" onClick={() => downloadDoc(doc)}>
                            Download
                          </button>
                          <button
                            type="button"
                            className="btn btn-ghost"
                            onClick={() => {
                              void shareDoc(doc);
                            }}
                          >
                            Share
                          </button>
                          {pendingDelete === doc.id ? (
                            <button
                              type="button"
                              className="btn btn-rust"
                              onClick={() => {
                                void deleteDocument({ data: doc.id }).then(() => {
                                  setPendingDelete(null);
                                  onChanged();
                                });
                              }}
                            >
                              Delete
                            </button>
                          ) : (
                            <button type="button" className="btn btn-ghost" onClick={() => setPendingDelete(doc.id)}>
                              Remove
                            </button>
                          )}
                        </div>
                      </li>
                    ))}
                  </ul>
                )}
              </Panel>
              <Panel title="Ledger">
                <ul className="flex flex-col gap-2 text-sm">
                  {companyEntries.slice(0, 12).map((entry) => (
                    <li key={entry.id}>
                      {formatDay(entry.entryDate)} · {movementLabel(entry.movement)} · {entry.quantity}{entry.cylinderType ? ` × ${entry.cylinderType}` : ""} · {paymentLabel(entry.paymentStatus)}
                    </li>
                  ))}
                </ul>
                <div className="mt-4">
                  <ExportBar title={`${balance.company} ledger`} filename={`cxyledge-${slug(balance.company)}`} lines={lines} csv={csv} />
                </div>
              </Panel>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}

function slug(value: string) {
  return value.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "company";
}

function readFile(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result ?? ""));
    reader.onerror = () => reject(new Error("Could not read that file."));
    reader.readAsDataURL(file);
  });
}

function downloadDoc(doc: DocRecord) {
  if (doc.content.startsWith("data:")) {
    const link = document.createElement("a");
    link.href = doc.content;
    link.download = doc.title;
    link.click();
    return;
  }
  downloadBlob(`${doc.title}.pdf`, makePdf(doc.title, doc.content.split("\n")));
}

async function shareDoc(doc: DocRecord) {
  if (doc.content.startsWith("data:")) {
    const response = await fetch(doc.content);
    const blob = await response.blob();
    await shareBlob(doc.title, blob, doc.title);
    return;
  }
  await shareBlob(`${doc.title}.pdf`, makePdf(doc.title, doc.content.split("\n")), doc.title);
}
