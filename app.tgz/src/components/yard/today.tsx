import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { ChevronLeft, ChevronRight, Trash2 } from "lucide-react";
import {
  KIND_META,
  addDays,
  compareMovements,
  dayFlows,
  formatCover,
  formatDay,
  formatDelta,
  knownParties,
  stockOf,
  todayISO,
  type MoveKind,
  type Movement,
} from "@/lib/inventory/model";
import { useYard } from "@/lib/inventory/store";
import { cn } from "@/lib/cn";
import { Field, Panel, Stat } from "@/components/yard/ui";

const QUICK_KINDS: MoveKind[] = ["receive_full", "issue_full", "collect_empty", "send_empty"];

function averageDailyIssue(movements: Movement[], typeId: string, end: string) {
  const from = addDays(end, -13);
  let issued = 0;
  for (const m of movements) {
    if (m.typeId !== typeId || m.kind !== "issue_full") continue;
    if (m.date < from || m.date > end) continue;
    issued += Math.abs(m.qty);
  }
  return issued / 14;
}

export function TodayView({ onSetup }: { onSetup: () => void }) {
  const types = useYard((s) => s.types);
  const movements = useYard((s) => s.movements);
  const addMovement = useYard((s) => s.addMovement);
  const removeMovement = useYard((s) => s.removeMovement);
  const restoreMovement = useYard((s) => s.restoreMovement);
  const reconcileDay = useYard((s) => s.reconcileDay);

  const today = todayISO();
  const [date, setDate] = useState(today);
  const active = types.filter((t) => !t.archived);
  const [typeId, setTypeId] = useState(active[0]?.id ?? "");
  const [kind, setKind] = useState<MoveKind>("issue_full");
  const [qty, setQty] = useState("1");
  const [party, setParty] = useState("");
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [saved, setSaved] = useState("");
  const [undo, setUndo] = useState<Movement | null>(null);
  const [countOpen, setCountOpen] = useState(movements.length === 0);
  const formRef = useRef<HTMLFormElement>(null);

  const activeKey = active.map((t) => t.id).join("|");

  useEffect(() => {
    const ids = activeKey.split("|").filter(Boolean);
    if (!typeId && ids[0]) setTypeId(ids[0]);
    if (typeId && !ids.includes(typeId) && ids[0]) setTypeId(ids[0]);
  }, [activeKey, typeId]);

  const flows = useMemo(() => dayFlows(movements, date), [movements, date]);
  const closing = useMemo(() => {
    let full = 0;
    let empty = 0;
    for (const t of active) {
      const s = stockOf(movements, t.id, { through: date });
      full += s.full;
      empty += s.empty;
    }
    return { full, empty };
  }, [active, movements, date]);
  const now = useMemo(() => {
    let full = 0;
    let empty = 0;
    for (const t of active) {
      const s = stockOf(movements, t.id, { through: today });
      full += s.full;
      empty += s.empty;
    }
    return { full, empty };
  }, [active, movements, today]);

  const dayMoves = useMemo(
    () =>
      movements
        .filter((m) => m.date === date)
        .sort((a, b) => compareMovements(b, a)),
    [movements, date],
  );
  const parties = useMemo(() => knownParties(movements), [movements]);

  if (active.length === 0) {
    return (
      <Panel title="No cylinder types yet">
        <p className="text-sm text-muted">
          Add the kinds you keep on the floor — domestic, commercial, oxygen, whatever you actually stock.
          Then log each day’s ins and outs here.
        </p>
        <button type="button" className="btn btn-rust mt-4" onClick={onSetup}>
          Add cylinder types
        </button>
      </Panel>
    );
  }

  function onQuick(nextType: string, nextKind: MoveKind) {
    setTypeId(nextType);
    setKind(nextKind);
    setError("");
    formRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    const input = formRef.current?.querySelector<HTMLInputElement>("[data-qty]");
    input?.focus();
  }

  function submit(e: FormEvent) {
    e.preventDefault();
    const parsed = Number(qty);
    const result = addMovement({
      date,
      typeId,
      kind,
      qty: parsed,
      party,
      note,
    });
    if (!result.ok) {
      setSaved("");
      setError(result.error);
      return;
    }
    setError("");
    const typeName = types.find((t) => t.id === typeId)?.name ?? "cylinders";
    setSaved(`${KIND_META[kind].short} ${Math.abs(parsed)} ${typeName}.`);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center gap-2">
        <button
          type="button"
          className="btn btn-ghost size-11 shrink-0 px-0"
          aria-label="Previous day"
          onClick={() => setDate((d) => addDays(d, -1))}
        >
          <ChevronLeft className="size-5" aria-hidden />
        </button>
        <div className="min-w-0 flex-1 text-center">
          <h2 className="font-display text-2xl sm:text-3xl">{formatDay(date)}</h2>
          <label className="mt-1 inline-block text-sm text-muted">
            <span className="sr-only">Choose date</span>
            <input
              type="date"
              className="field mx-auto mt-1 max-w-44"
              value={date}
              onChange={(e) => e.target.value && setDate(e.target.value)}
            />
          </label>
        </div>
        <button
          type="button"
          className="btn btn-ghost size-11 shrink-0 px-0"
          aria-label="Next day"
          onClick={() => setDate((d) => addDays(d, 1))}
        >
          <ChevronRight className="size-5" aria-hidden />
        </button>
      </div>
      {date !== today ? (
        <p className="text-center text-sm text-muted">
          Today’s floor is {now.full} full · {now.empty} empty.{" "}
          <button type="button" className="font-semibold text-rust" onClick={() => setDate(today)}>
            Jump to today
          </button>
        </p>
      ) : null}

      <div className="grid grid-cols-2 gap-3">
        <Stat label="Full at close" value={closing.full} tone="pine" />
        <Stat label="Empty at close" value={closing.empty} />
        <Stat label="Issued this day" value={flows.issued} tone="rust" />
        <Stat label="Received this day" value={flows.received} />
      </div>

      <Panel title="Log a movement" className="scroll-mt-20">
        <form ref={formRef} onSubmit={submit} className="flex flex-col gap-4">
          <fieldset>
            <legend className="mb-1.5 text-sm font-medium">Cylinder</legend>
            <div className="flex flex-wrap gap-2">
              {active.map((t) => (
                <button
                  key={t.id}
                  type="button"
                  className={cn(
                    "btn min-h-11",
                    typeId === t.id ? "btn-pine" : "btn-ghost",
                  )}
                  onClick={() => setTypeId(t.id)}
                >
                  {t.name}
                  {t.size ? <span className="font-normal opacity-80">{t.size}</span> : null}
                </button>
              ))}
            </div>
          </fieldset>
          <fieldset>
            <legend className="mb-1.5 text-sm font-medium">What happened</legend>
            <div className="grid grid-cols-2 gap-2">
              {QUICK_KINDS.map((k) => (
                <button
                  key={k}
                  type="button"
                  className={cn("btn", kind === k ? "btn-rust" : "btn-ghost")}
                  onClick={() => setKind(k)}
                >
                  {KIND_META[k].verb}
                </button>
              ))}
            </div>
          </fieldset>
          <Field label="Cylinders" hint="Whole cylinders only.">
            <div className="flex gap-2">
              <button
                type="button"
                className="btn btn-ghost size-11 px-0"
                aria-label="Decrease quantity"
                onClick={() => setQty((q) => String(Math.max(1, (Number(q) || 1) - 1)))}
              >
                −
              </button>
              <input
                data-qty
                className="field text-center tabular-nums"
                inputMode="numeric"
                value={qty}
                onChange={(e) => setQty(e.target.value.replace(/[^\d]/g, ""))}
                aria-label="Quantity"
              />
              <button
                type="button"
                className="btn btn-ghost size-11 px-0"
                aria-label="Increase quantity"
                onClick={() => setQty((q) => String((Number(q) || 0) + 1))}
              >
                +
              </button>
            </div>
          </Field>
          <Field
            label={kind === "issue_full" || kind === "collect_empty" ? "Customer" : "Party"}
            hint="Optional. Used later to see who took stock."
          >
            <input
              className="field"
              list="yard-parties"
              value={party}
              onChange={(e) => setParty(e.target.value)}
              placeholder={kind === "receive_full" || kind === "send_empty" ? "Plant or supplier" : "Customer or route"}
            />
            <datalist id="yard-parties">
              {parties.map((p) => (
                <option key={p} value={p} />
              ))}
            </datalist>
          </Field>
          <Field label="Note">
            <input
              className="field"
              value={note}
              maxLength={160}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Optional"
            />
          </Field>
          {error ? (
            <p role="alert" className="text-sm text-rust">
              {error}
            </p>
          ) : null}
          {saved ? (
            <p role="status" className="text-sm text-pine">
              {saved}
            </p>
          ) : null}
          <button type="submit" className="btn btn-rust w-full">
            Add to {formatDay(date)}
          </button>
        </form>
      </Panel>

      <section>
        <h2 className="mb-3 font-display text-2xl">Floor at close</h2>
        <ul className="grid gap-3">
          {active.map((t) => {
            const s = stockOf(movements, t.id, { through: date });
            const avg = averageDailyIssue(movements, t.id, date > today ? today : date);
            const low = s.full <= t.lowFull;
            return (
              <li key={t.id} className="rounded-xl border border-line bg-card p-4">
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <h3 className="font-display text-xl leading-tight">{t.name}</h3>
                    {t.size ? <p className="text-sm text-muted">{t.size}</p> : null}
                  </div>
                  {low ? (
                    <span className="rounded-full bg-sand px-2.5 py-1 text-xs font-semibold text-rust">
                      Low full
                    </span>
                  ) : null}
                </div>
                <dl className="mt-3 grid grid-cols-2 gap-3">
                  <div>
                    <dt className="text-sm text-muted">Full</dt>
                    <dd className={cn("text-2xl font-semibold tabular-nums", s.full < 0 ? "text-rust" : "text-pine")}>
                      {s.full}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-sm text-muted">Empty</dt>
                    <dd className={cn("text-2xl font-semibold tabular-nums", s.empty < 0 && "text-rust")}>{s.empty}</dd>
                  </div>
                </dl>
                <p className="mt-2 text-sm text-muted">{formatCover(s.full, avg)}</p>
                <div className="mt-3 grid grid-cols-2 gap-2">
                  {QUICK_KINDS.map((k) => (
                    <button key={k} type="button" className="btn btn-soft" onClick={() => onQuick(t.id, k)}>
                      {KIND_META[k].verb}
                    </button>
                  ))}
                </div>
              </li>
            );
          })}
        </ul>
        <p className="mt-2 text-xs text-muted">{averageLabel}</p>
      </section>

      <Panel title="This day’s book">
        {dayMoves.length === 0 ? (
          <p className="text-sm text-muted">Nothing logged for this day yet.</p>
        ) : (
          <ul className="divide-y divide-line">
            {dayMoves.map((m) => {
              const t = types.find((x) => x.id === m.typeId);
              const signed = m.kind === "adjust_full" || m.kind === "adjust_empty";
              return (
                <li key={m.id} className="flex items-start gap-3 py-3 first:pt-0 last:pb-0">
                  <div className="min-w-0 flex-1">
                    <p className="font-medium">
                      {KIND_META[m.kind].short}
                      <span className="text-muted"> · </span>
                      {t?.name ?? "Unknown type"}
                      <span className="ml-2 tabular-nums">
                        {signed ? formatDelta(m.qty) : Math.abs(m.qty)}
                      </span>
                    </p>
                    {m.party || m.note ? (
                      <p className="truncate text-sm text-muted">
                        {[m.party, m.note].filter(Boolean).join(" — ")}
                      </p>
                    ) : null}
                  </div>
                  <button
                    type="button"
                    className="btn btn-ghost size-11 shrink-0 px-0"
                    aria-label={`Remove ${KIND_META[m.kind].short} of ${Math.abs(m.qty)} ${t?.name ?? "cylinders"}`}
                    onClick={() => {
                      setUndo(m);
                      removeMovement(m.id);
                    }}
                  >
                    <Trash2 className="size-4" aria-hidden />
                  </button>
                </li>
              );
            })}
          </ul>
        )}
      </Panel>

      <Reconcile
        open={countOpen}
        onToggle={() => setCountOpen((v) => !v)}
        date={date}
        onSave={(rows) => {
          const err = reconcileDay(date, rows);
          return err;
        }}
      />

      {undo ? (
        <div className="no-print fixed inset-x-4 bottom-24 z-40 mx-auto flex max-w-md items-center justify-between gap-3 rounded-xl bg-ink px-4 py-3 text-paper lg:bottom-6">
          <p className="text-sm">Entry removed from this browser.</p>
          <button
            type="button"
            className="text-sm font-semibold underline"
            onClick={() => {
              restoreMovement(undo);
              setUndo(null);
            }}
          >
            Undo
          </button>
        </div>
      ) : null}
    </div>
  );
}

function Reconcile({
  date,
  open,
  onToggle,
  onSave,
}: {
  date: string;
  open: boolean;
  onToggle: () => void;
  onSave: (rows: Array<{ typeId: string; full: number; empty: number }>) => string | null;
}) {
  const types = useYard((s) => s.types);
  const movements = useYard((s) => s.movements);
  const active = types.filter((t) => !t.archived);
  const [draft, setDraft] = useState<Record<string, { full: string; empty: string }>>({});
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    const next: Record<string, { full: string; empty: string }> = {};
    for (const t of active) {
      const s = stockOf(movements, t.id, { through: date });
      next[t.id] = { full: String(s.full), empty: String(s.empty) };
    }
    setDraft(next);
  }, [date, movements, types]);

  return (
    <section className="no-print rounded-xl border border-line bg-card">
      <button type="button" className="flex w-full items-center justify-between gap-3 px-4 py-4 text-left" onClick={onToggle}>
        <span>
          <span className="block font-display text-2xl">Physical count</span>
          <span className="mt-1 block text-sm text-muted">
            Type what is actually on the floor. The book stores only the difference.
          </span>
        </span>
        <span className="text-sm font-semibold text-rust">{open ? "Hide" : "Open"}</span>
      </button>
      {open ? (
        <form
          className="flex flex-col gap-4 border-t border-line px-4 py-4"
          onSubmit={(e) => {
            e.preventDefault();
            const rows = active.map((t) => ({
              typeId: t.id,
              full: Number(draft[t.id]?.full),
              empty: Number(draft[t.id]?.empty),
            }));
            const err = onSave(rows);
            if (err) {
              setMessage("");
              setError(err);
            } else {
              setError("");
              setMessage("Count saved for this day.");
            }
          }}
        >
          {active.map((t) => (
            <div key={t.id} className="grid gap-2 sm:grid-cols-[1fr_8rem_8rem] sm:items-end">
              <p className="text-sm font-medium">
                {t.name}
                {t.size ? <span className="font-normal text-muted"> · {t.size}</span> : null}
              </p>
              <Field label="Full">
                <input
                  className="field tabular-nums"
                  inputMode="numeric"
                  value={draft[t.id]?.full ?? ""}
                  onChange={(e) =>
                    setDraft((d) => ({
                      ...d,
                      [t.id]: { full: e.target.value.replace(/[^\d]/g, ""), empty: d[t.id]?.empty ?? "" },
                    }))
                  }
                />
              </Field>
              <Field label="Empty">
                <input
                  className="field tabular-nums"
                  inputMode="numeric"
                  value={draft[t.id]?.empty ?? ""}
                  onChange={(e) =>
                    setDraft((d) => ({
                      ...d,
                      [t.id]: { empty: e.target.value.replace(/[^\d]/g, ""), full: d[t.id]?.full ?? "" },
                    }))
                  }
                />
              </Field>
            </div>
          ))}
          {error ? (
            <p role="alert" className="text-sm text-rust">
              {error}
            </p>
          ) : null}
          {message ? (
            <p role="status" className="text-sm text-pine">
              {message}
            </p>
          ) : null}
          <button type="submit" className="btn btn-pine w-full sm:w-auto">
            Save count for this day
          </button>
        </form>
      ) : null}
    </section>
  );
}

const averageLabel = "Cover uses the last 14 days of issues, ending on the selected day.";
