import { useMemo, useState } from "react";
import { Trash2 } from "lucide-react";
import {
  KIND_META,
  compareMovements,
  dayFlows,
  dayLines,
  formatDay,
  formatDelta,
  recordedDates,
  type Movement,
} from "@/lib/inventory/model";
import { useYard } from "@/lib/inventory/store";
import { EmptyNote, Panel } from "@/components/yard/ui";

const PAGE = 14;

export function DaysView() {
  const types = useYard((s) => s.types);
  const movements = useYard((s) => s.movements);
  const removeMovement = useYard((s) => s.removeMovement);
  const restoreMovement = useYard((s) => s.restoreMovement);
  const dates = useMemo(() => recordedDates(movements), [movements]);
  const [shown, setShown] = useState(PAGE);
  const [open, setOpen] = useState<string | null>(null);
  const [undo, setUndo] = useState<Movement | null>(null);
  const visible = dates.slice(0, shown);

  if (dates.length === 0) {
    return (
      <EmptyNote title="No days in the book yet">
        Log a receipt, an issue, or an opening count on Today. Each day you touch will show up here as a roll-up.
      </EmptyNote>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      <div>
        <h2 className="font-display text-3xl">Day register</h2>
        <p className="mt-1 text-sm text-muted">
          Opening, movement, and close for every day that has an entry. Newest first.
        </p>
      </div>
      {visible.map((date) => {
        const flows = dayFlows(movements, date);
        const expanded = open === date;
        return (
          <section key={date} className="rounded-xl border border-line bg-card">
            <button
              type="button"
              className="flex w-full items-start justify-between gap-3 px-4 py-3 text-left"
              aria-expanded={expanded}
              onClick={() => setOpen(expanded ? null : date)}
            >
              <span className="font-medium">{formatDay(date)}</span>
              <span className="text-right text-sm tabular-nums text-muted">
                Issued {flows.issued}
                <span className="hidden sm:inline"> · Received {flows.received}</span>
                <span className="block sm:inline"> · Empty in {flows.emptyIn}</span>
              </span>
            </button>
            {expanded ? (
              <DayDetail
                date={date}
                onRemove={(m) => {
                  setUndo(m);
                  removeMovement(m.id);
                }}
              />
            ) : null}
          </section>
        );
      })}
      {shown < dates.length ? (
        <button type="button" className="btn btn-ghost w-full" onClick={() => setShown((n) => n + PAGE)}>
          Show earlier days
        </button>
      ) : null}
      {undo ? (
        <div className="no-print fixed inset-x-4 bottom-24 z-40 mx-auto flex max-w-md items-center justify-between gap-3 rounded-xl bg-ink px-4 py-3 text-paper lg:bottom-6">
          <p className="text-sm">Entry removed from this browser.</p>
          <button
            type="button"
            className="text-sm font-semibold underline"
            onClick={() => {
              restoreMovement(undo);
              setUndo(null);
            }}
          >
            Undo
          </button>
        </div>
      ) : null}
    </div>
  );
}

function DayDetail({ date, onRemove }: { date: string; onRemove: (m: Movement) => void }) {
  const types = useYard((s) => s.types);
  const movements = useYard((s) => s.movements);
  const lines = dayLines(types, movements, date);
  const entries = movements.filter((m) => m.date === date).sort((a, b) => compareMovements(b, a));

  return (
    <div className="flex flex-col gap-4 border-t border-line px-4 py-4">
      {lines.map((line) => (
        <div key={line.type.id}>
          <h3 className="font-medium">
            {line.type.name}
            {line.type.size ? <span className="font-normal text-muted"> · {line.type.size}</span> : null}
          </h3>
          <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-sm sm:grid-cols-4">
            <Pair k="Open full" v={line.openFull} />
            <Pair k="In" v={line.inFull} />
            <Pair k="Out" v={line.outFull} />
            <Pair k="Close full" v={line.closeFull} strong />
            <Pair k="Open empty" v={line.openEmpty} />
            <Pair k="Empty in" v={line.inEmpty} />
            <Pair k="Empty out" v={line.outEmpty} />
            <Pair k="Close empty" v={line.closeEmpty} strong />
          </dl>
          {line.adjFull !== 0 || line.adjEmpty !== 0 ? (
            <p className="mt-1 text-xs text-muted">
              Count correction: full {formatDelta(line.adjFull)}, empty {formatDelta(line.adjEmpty)}
            </p>
          ) : null}
        </div>
      ))}
      <Panel title="Entries" className="p-0 sm:p-0">
        <ul className="divide-y divide-line">
          {entries.map((m) => {
            const t = types.find((x) => x.id === m.typeId);
            const signed = m.kind === "adjust_full" || m.kind === "adjust_empty";
            return (
              <li key={m.id} className="flex items-start gap-3 px-4 py-3">
                <div className="min-w-0 flex-1">
                  <p className="text-sm font-medium">
                    {KIND_META[m.kind].short} · {t?.name ?? "Unknown type"}{" "}
                    <span className="tabular-nums">{signed ? formatDelta(m.qty) : Math.abs(m.qty)}</span>
                  </p>
                  {m.party || m.note ? (
                    <p className="truncate text-sm text-muted">{[m.party, m.note].filter(Boolean).join(" — ")}</p>
                  ) : null}
                </div>
                <button
                  type="button"
                  className="btn btn-ghost size-11 shrink-0 px-0"
                  aria-label={`Remove ${KIND_META[m.kind].short}`}
                  onClick={() => onRemove(m)}
                >
                  <Trash2 className="size-4" aria-hidden />
                </button>
              </li>
            );
          })}
        </ul>
      </Panel>
    </div>
  );
}

function Pair({ k, v, strong }: { k: string; v: number; strong?: boolean }) {
  return (
    <div className="flex items-baseline justify-between gap-2 border-b border-line py-1">
      <dt className="text-muted">{k}</dt>
      <dd className={strong ? "font-semibold tabular-nums text-pine" : "tabular-nums"}>{v}</dd>
    </div>
  );
}
