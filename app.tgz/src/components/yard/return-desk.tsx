import { useEffect, useMemo, useState } from "react";
import { recordReturn, type Entry, type ReturnLog } from "@/lib/inventory/api";
import { openOrders } from "@/lib/inventory/analyse";
import { formatDay } from "@/lib/inventory/model";
import { cn } from "@/lib/cn";
import { Field } from "@/components/yard/ui";

export function ReturnDesk({
  entries,
  logs,
  userId,
  onChanged,
}: {
  entries: Entry[];
  logs: ReturnLog[];
  userId: string;
  onChanged: () => void;
}) {
  const [advanced, setAdvanced] = useState(false);
  const [activity, setActivity] = useState(0);
  const [orderId, setOrderId] = useState("");
  const [picked, setPicked] = useState<string[]>([]);
  const [quantity, setQuantity] = useState(1);
  const [note, setNote] = useState("");
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);
  const orders = useMemo(() => openOrders(entries), [entries]);
  const order = orders.find((item) => item.entry.id === orderId) ?? orders[0];

  useEffect(() => {
    if (!advanced) return;
    const timer = window.setTimeout(() => setAdvanced(false), 75000);
    return () => window.clearTimeout(timer);
  }, [advanced, activity]);

  useEffect(() => {
    setPicked([]);
    setQuantity(1);
  }, [order?.entry.id]);

  function bump() {
    setActivity((value) => value + 1);
  }

  async function submit() {
    if (!order) return;
    setPending(true);
    setError("");
    const result = await recordReturn({
      data: {
        entryId: order.entry.id,
        serials: picked,
        quantity,
        note,
      },
    });
    setPending(false);
    if (!result.ok) {
      setError(result.error);
      bump();
      return;
    }
    setAdvanced(false);
    setNote("");
    setPicked([]);
    onChanged();
  }

  return (
    <section className="mt-8 border-t border-line pt-6" onPointerDown={bump} onKeyDown={bump}>
      <div className="flex items-center justify-between gap-3">
        <div>
          <p className="text-sm font-medium">Advanced return / exchange</p>
          <p className="text-xs text-muted">Off by default. It turns itself off after you finish, or if you leave it idle.</p>
        </div>
        <button
          type="button"
          role="switch"
          aria-checked={advanced}
          aria-label="Advanced return mode"
          className={cn("inline-flex h-11 w-16 items-center rounded-full p-1", advanced ? "bg-pine" : "bg-line")}
          onClick={() => {
            setAdvanced((value) => !value);
            setError("");
            bump();
          }}
        >
          <span className={cn("size-5 rounded-full bg-card", advanced && "ml-auto")} />
        </button>
      </div>

      {advanced ? (
        <div className="mt-4 rounded-xl border border-line bg-sand p-4">
          <p className="text-sm text-ink">
            Mark cylinders from one open delivery as received. Those serials leave the outstanding balance, and the action is logged.
          </p>
          {orders.length === 0 ? (
            <p className="mt-3 text-sm text-muted">No open deliveries. Everything booked out has already come back.</p>
          ) : (
            <div className="mt-3 grid gap-3">
              <Field label="Open delivery">
                <select
                  className="field"
                  value={order?.entry.id ?? ""}
                  onChange={(event) => setOrderId(event.target.value)}
                >
                  {orders.map((item) => (
                    <option key={item.entry.id} value={item.entry.id}>
                      {item.entry.companyName} · {formatDay(item.entry.entryDate)} · {item.leftQty} still out
                    </option>
                  ))}
                </select>
              </Field>
              {order && order.leftSerials.length > 0 ? (
                <fieldset>
                  <legend className="mb-2 text-sm font-medium">Serials still out</legend>
                  <div className="flex flex-col gap-2">
                    {order.leftSerials.map((serial) => {
                      const on = picked.includes(serial);
                      return (
                        <label key={serial} className="flex min-h-11 items-center gap-3 text-sm">
                          <input
                            type="checkbox"
                            checked={on}
                            onChange={() =>
                              setPicked((current) =>
                                current.includes(serial) ? current.filter((item) => item !== serial) : [...current, serial],
                              )
                            }
                          />
                          {serial}
                        </label>
                      );
                    })}
                  </div>
                </fieldset>
              ) : (
                <Field label="How many came back" hint={`Up to ${order?.leftQty ?? 0}. This delivery has no serials.`}>
                  <input
                    className="field tabular-nums"
                    inputMode="numeric"
                    value={String(quantity)}
                    onChange={(event) => setQuantity(Number(event.target.value.replace(/[^\d]/g, "") || "0"))}
                  />
                </Field>
              )}
              <Field label="Note">
                <input className="field" value={note} maxLength={300} onChange={(event) => setNote(event.target.value)} placeholder="Optional" />
              </Field>
              {error ? (
                <p role="alert" className="text-sm text-rust">
                  {error}
                </p>
              ) : null}
              <button type="button" className="btn btn-rust w-fit" disabled={pending || !order} onClick={() => void submit()}>
                {pending ? "Saving…" : "Mark received"}
              </button>
            </div>
          )}
          {logs.length > 0 ? (
            <ul className="mt-4 flex flex-col gap-2 text-sm">
              {logs.slice(0, 5).map((log) => (
                <li key={log.id} className="rounded-lg bg-card px-3 py-2">
                  {log.companyName} · {log.quantity} received
                  {log.serials ? ` · ${log.serials.replace(/\n/g, ", ")}` : ""}
                  <span className="block text-xs text-muted">
                    {new Date(log.createdAt).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short" })}
                    {log.actor === userId ? " · by you" : " · by a teammate"}
                  </span>
                </li>
              ))}
            </ul>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
