import { useEffect, useState } from "react";
import { createYard, joinYard, renameYard, switchYard, type YardInfo } from "@/lib/inventory/api";
import { Field, Panel } from "@/components/yard/ui";

export function YardPanel({ yard, onChanged }: { yard: YardInfo; onChanged: () => void }) {
  const [name, setName] = useState(yard.name);
  const [code, setCode] = useState("");
  const [fresh, setFresh] = useState("");
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    setName(yard.name);
  }, [yard.name]);

  return (
    <div className="flex flex-col gap-4">
      <Panel title="This account">
        <p className="text-sm text-muted">
          {yard.members} {yard.members === 1 ? "person" : "people"} can update this book. The same sign-in on a phone or a computer sees the same lines.
        </p>
        <form
          className="mt-3 flex flex-col gap-3 sm:flex-row sm:items-end"
          onSubmit={async (event) => {
            event.preventDefault();
            setError("");
            const result = await renameYard({ data: name });
            if (!result.ok) {
              setError(result.error);
              return;
            }
            setMessage("Account name saved.");
            onChanged();
          }}
        >
          <div className="flex-1">
            <Field label="Name on the header and bills">
              <input className="field" value={name} maxLength={60} onChange={(event) => setName(event.target.value)} />
            </Field>
          </div>
          <button type="submit" className="btn btn-pine">
            Save name
          </button>
        </form>
      </Panel>

      <Panel title="Accounts">
        <p className="mb-3 text-sm text-muted">Each account has its own cylinders, bills, and files. The active one is marked.</p>
        <div className="flex flex-col gap-2">
          {yard.yards.map((item) => (
            <button
              key={item.id}
              type="button"
              className={item.active ? "btn btn-pine justify-start" : "btn btn-ghost justify-start"}
              onClick={async () => {
                if (item.active) return;
                const result = await switchYard({ data: item.id });
                if (!result.ok) {
                  setError(result.error);
                  return;
                }
                setMessage(`Now using ${item.name}.`);
                onChanged();
              }}
            >
              {item.name}
              {item.active ? " · active" : ""}
            </button>
          ))}
        </div>
        <form
          className="mt-4 flex flex-col gap-3 sm:flex-row sm:items-end"
          onSubmit={async (event) => {
            event.preventDefault();
            setError("");
            const result = await createYard({ data: fresh });
            if (!result.ok) {
              setError(result.error);
              return;
            }
            setFresh("");
            setMessage("New account created and selected.");
            onChanged();
          }}
        >
          <div className="flex-1">
            <Field label="Add another company account">
              <input className="field" value={fresh} maxLength={60} onChange={(event) => setFresh(event.target.value)} placeholder="Second yard" />
            </Field>
          </div>
          <button type="submit" className="btn btn-rust">
            Add account
          </button>
        </form>
      </Panel>

      <Panel title="Share code">
        <p className="text-sm text-muted">Someone else signs in, enters this code, and their entries land in this account.</p>
        <p className="mt-3 font-mono text-2xl tracking-widest text-ink">{yard.inviteCode}</p>
        <button
          type="button"
          className="btn btn-ghost mt-3"
          onClick={() => {
            void navigator.clipboard?.writeText(yard.inviteCode);
            setMessage("Code copied.");
            setError("");
          }}
        >
          Copy code
        </button>
      </Panel>

      <Panel title="Join with a code">
        <form
          className="flex flex-col gap-3 sm:flex-row sm:items-end"
          onSubmit={async (event) => {
            event.preventDefault();
            setError("");
            const result = await joinYard({ data: code });
            if (!result.ok) {
              setError(result.error);
              return;
            }
            setCode("");
            setMessage("Joined. This device is now on that account.");
            onChanged();
          }}
        >
          <div className="flex-1">
            <Field label="Code from the other phone or office">
              <input
                className="field font-mono tracking-widest uppercase"
                value={code}
                onChange={(event) => setCode(event.target.value.toUpperCase())}
                placeholder="AB12CD34"
                autoCapitalize="characters"
              />
            </Field>
          </div>
          <button type="submit" className="btn btn-rust">
            Join
          </button>
        </form>
      </Panel>

      {error ? (
        <p role="alert" className="text-sm text-rust">
          {error}
        </p>
      ) : null}
      {message ? (
        <p role="status" className="text-sm text-pine">
          {message}
        </p>
      ) : null}
    </div>
  );
}
