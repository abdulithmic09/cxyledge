import { useState } from "react";
import { GAS_TEMPLATES, LPG_TEMPLATES } from "@/lib/inventory/model";
import { useYard } from "@/lib/inventory/store";
import { Field, Panel } from "@/components/yard/ui";

export function CatalogView() {
  const types = useYard((s) => s.types);
  const movements = useYard((s) => s.movements);
  const addType = useYard((s) => s.addType);
  const [name, setName] = useState("");
  const [size, setSize] = useState("");
  const [lowFull, setLowFull] = useState("10");
  const [error, setError] = useState("");

  function addTemplates(list: Array<{ name: string; size: string; lowFull: number }>) {
    const have = new Set(types.map((t) => t.name.toLowerCase()));
    let added = 0;
    for (const item of list) {
      if (have.has(item.name.toLowerCase())) continue;
      addType(item);
      added += 1;
    }
    setError(added === 0 ? "Those names are already in the yard." : "");
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-3xl">Cylinder types</h2>
        <p className="mt-1 max-w-xl text-sm text-muted">
          Each type is a kind of cylinder you count separately. Quantities everywhere else are counts of cylinders, not kilograms.
        </p>
      </div>

      {types.length === 0 ? (
        <Panel title="Start from a common set">
          <p className="text-sm text-muted">Or skip this and add your own names below.</p>
          <div className="mt-3 flex flex-col gap-2 sm:flex-row">
            <button type="button" className="btn btn-pine" onClick={() => addTemplates(LPG_TEMPLATES)}>
              LPG sizes
            </button>
            <button type="button" className="btn btn-ghost" onClick={() => addTemplates(GAS_TEMPLATES)}>
              Industrial gases
            </button>
          </div>
        </Panel>
      ) : (
        <div className="flex flex-wrap gap-2">
          <button type="button" className="btn btn-soft" onClick={() => addTemplates(LPG_TEMPLATES)}>
            Add LPG sizes
          </button>
          <button type="button" className="btn btn-soft" onClick={() => addTemplates(GAS_TEMPLATES)}>
            Add industrial gases
          </button>
        </div>
      )}

      <ul className="flex flex-col gap-3">
        {types.map((t) => (
          <TypeCard key={t.id} id={t.id} used={movements.some((m) => m.typeId === t.id)} />
        ))}
      </ul>

      <Panel title="Add a type">
        <form
          className="grid gap-3 sm:grid-cols-2"
          onSubmit={(e) => {
            e.preventDefault();
            const id = addType({ name, size, lowFull: Number(lowFull) });
            if (!id) {
              setError("Give the type a name.");
              return;
            }
            setName("");
            setSize("");
            setLowFull("10");
            setError("");
          }}
        >
          <Field label="Name">
            <input className="field" value={name} onChange={(e) => setName(e.target.value)} placeholder="Oxygen" />
          </Field>
          <Field label="Size or spec" hint="A label only, so you can tell them apart.">
            <input className="field" value={size} onChange={(e) => setSize(e.target.value)} placeholder="47 L" />
          </Field>
          <Field label="Alert when full drops to" hint="Shown on Today when the book is at or under this.">
            <input
              className="field tabular-nums"
              inputMode="numeric"
              value={lowFull}
              onChange={(e) => setLowFull(e.target.value.replace(/[^\d]/g, ""))}
            />
          </Field>
          <div className="flex items-end">
            <button type="submit" className="btn btn-rust w-full">
              Add type
            </button>
          </div>
          {error ? (
            <p role="alert" className="text-sm text-rust sm:col-span-2">
              {error}
            </p>
          ) : null}
        </form>
      </Panel>
    </div>
  );
}

function TypeCard({ id, used }: { id: string; used: boolean }) {
  const type = useYard((s) => s.types.find((t) => t.id === id));
  const updateType = useYard((s) => s.updateType);
  const setArchived = useYard((s) => s.setArchived);
  const removeType = useYard((s) => s.removeType);
  const [name, setName] = useState(type?.name ?? "");
  const [size, setSize] = useState(type?.size ?? "");
  const [lowFull, setLowFull] = useState(String(type?.lowFull ?? 0));
  const [note, setNote] = useState("");

  if (!type) return null;

  return (
    <li className="rounded-xl border border-line bg-card p-4">
      <form
        className="grid gap-3 sm:grid-cols-2"
        onSubmit={(e) => {
          e.preventDefault();
          updateType(id, { name, size, lowFull: Number(lowFull) });
          setNote("Saved.");
        }}
      >
        <Field label="Name">
          <input className="field" value={name} onChange={(e) => setName(e.target.value)} />
        </Field>
        <Field label="Size or spec">
          <input className="field" value={size} onChange={(e) => setSize(e.target.value)} />
        </Field>
        <Field label="Low-full alert">
          <input
            className="field tabular-nums"
            inputMode="numeric"
            value={lowFull}
            onChange={(e) => setLowFull(e.target.value.replace(/[^\d]/g, ""))}
          />
        </Field>
        <div className="flex flex-wrap items-end gap-2">
          <button type="submit" className="btn btn-pine">
            Save
          </button>
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => {
              setArchived(id, !type.archived);
              setNote(type.archived ? "Back on the floor." : "Archived. History stays.");
            }}
          >
            {type.archived ? "Restore" : "Archive"}
          </button>
          {!used ? (
            <button
              type="button"
              className="btn btn-ghost"
              onClick={() => {
                removeType(id);
              }}
            >
              Delete
            </button>
          ) : null}
        </div>
      </form>
      {type.archived ? <p className="mt-2 text-xs text-muted">Archived types stay out of today’s logger.</p> : null}
      {used ? <p className="mt-1 text-xs text-muted">This type has entries, so it can be archived but not deleted.</p> : null}
      {note ? <p className="mt-1 text-sm text-pine">{note}</p> : null}
    </li>
  );
}
