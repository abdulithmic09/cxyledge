import { useMemo, useState } from "react";
import { createEntry, saveDocument, type Entry, type PaymentStatus, type YardInfo } from "@/lib/inventory/api";
import { paymentLabel } from "@/lib/inventory/analyse";
import { rupee, splitSerials, subtotal, cylinderTypeOptions } from "@/lib/inventory/serials";
import { toCsv } from "@/lib/inventory/files";
import { cn } from "@/lib/cn";
import { ExportBar } from "@/components/yard/export-bar";
import { Field, Panel } from "@/components/yard/ui";

type BillKind = "sale" | "purchase";

function todayISO() {
  const date = new Date();
  return `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}-${String(date.getDate()).padStart(2, "0")}`;
}

function nextBillNo(entries: Entry[], date: string) {
  const prefix = `CX-${date.replace(/-/g, "")}-`;
  let next = 1;
  for (const entry of entries) {
    if (!entry.billNo.startsWith(prefix)) continue;
    const value = Number(entry.billNo.slice(prefix.length));
    if (value >= next) next = value + 1;
  }
  return `${prefix}${String(next).padStart(2, "0")}`;
}

export function BillsView({ yard, entries, onChanged }: { yard: YardInfo; entries: Entry[]; onChanged: () => void }) {
  const [kind, setKind] = useState<BillKind>("sale");
  const [billNo, setBillNo] = useState(() => nextBillNo(entries, todayISO()));
  const [date, setDate] = useState(todayISO);
  const [company, setCompany] = useState("");
  const [serialNo, setSerialNo] = useState("");
  const [qtyOverride, setQtyOverride] = useState(false);
  const [quantity, setQuantity] = useState(0);
  const [price, setPrice] = useState<number | null>(null);
  const [finalAmount, setFinalAmount] = useState<number | null>(null);
  const [finalTouched, setFinalTouched] = useState(false);
  const [payment, setPayment] = useState<PaymentStatus>("unpaid");
  const [paid, setPaid] = useState<number | null>(null);
  const [note, setNote] = useState("");
  const [cylinderType, setCylinderType] = useState("");
  const [error, setError] = useState("");
  const [saved, setSaved] = useState("");
  const [pending, setPending] = useState(false);
  const names = useMemo(() => [...new Set(entries.map((entry) => entry.companyName))].sort(), [entries]);
  const counted = splitSerials(serialNo);
  const qty = qtyOverride ? quantity : counted.length;
  const goods = subtotal(qty, price);
  const total = finalTouched ? finalAmount : goods;

  function onSerials(value: string) {
    const nextQty = qtyOverride ? quantity : splitSerials(value).length;
    setSerialNo(value);
    setQuantity(nextQty);
    if (!finalTouched) setFinalAmount(subtotal(nextQty, price));
  }

  const lines = billLines({
    yard,
    kind,
    billNo,
    date,
    company: company || "Company",
    serials: counted,
    quantity: qty,
    price,
    total,
    payment,
    paid,
    note,
    cylinderType,
  });
  const csv = toCsv(
    ["Bill", "Date", "Kind", "Company", "Serials", "Qty", "Price", "Total", "Payment", "Received"],
    [[billNo, date, kind, company, counted.join(" "), String(qty), price == null ? "" : String(price), total == null ? "" : String(total), paymentLabel(payment), paid == null ? "" : String(paid)]],
  );

  async function save() {
    setError("");
    setSaved("");
    if (!company.trim()) {
      setError("Enter the company name.");
      return;
    }
    setPending(true);
    const entry = await createEntry({
      data: {
        companyName: company,
        entryDate: date,
        serialNo,
        quantity: qty,
        paymentStatus: payment,
        amountDue: total,
        amountPaid: paid,
        note,
        movement: kind === "purchase" ? "purchase" : "delivery",
        unitPrice: price,
        billNo,
        parentId: null,
        qtyOverride,
        cylinderType,
      },
    });
    if (!entry.ok) {
      setPending(false);
      setError(entry.error);
      return;
    }
    const doc = await saveDocument({
      data: {
        companyName: company.trim(),
        title: `${billNo || "Bill"} ${company.trim()}`,
        kind: "bill",
        mime: "text/plain",
        content: lines.join("\n"),
      },
    });
    setPending(false);
    if (!doc.ok) {
      setError(doc.error);
      return;
    }
    setSaved("Bill saved in the book and in that company's files.");
    setBillNo(nextBillNo([...entries, entry.entry], date));
    setSerialNo("");
    setQuantity(0);
    setNote("");
    onChanged();
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-3xl">Bills</h2>
        <p className="mt-1 text-sm text-muted">Sale and purchase bills use this account’s letterhead and stay in the company folder.</p>
      </div>
      <div className="grid gap-4 lg:grid-cols-2">
        <Panel title="New bill">
          <div className="grid gap-3">
            <div className="grid grid-cols-2 gap-2">
              {(["sale", "purchase"] as const).map((item) => (
                <button key={item} type="button" className={cn("btn", kind === item ? "btn-pine" : "btn-ghost")} onClick={() => setKind(item)}>
                  {item === "sale" ? "Sale" : "Purchase"}
                </button>
              ))}
            </div>
            <Field label="Bill number">
              <input className="field" value={billNo} maxLength={40} onChange={(event) => setBillNo(event.target.value)} />
            </Field>
            <Field label="Date">
              <input
                type="date"
                className="field"
                value={date}
                onChange={(event) => {
                  setDate(event.target.value);
                  setBillNo(nextBillNo(entries, event.target.value));
                }}
              />
            </Field>
            <Field label="Company">
              <input className="field" value={company} list="bill-companies" onChange={(event) => setCompany(event.target.value)} placeholder="Sharma Stores" />
              <datalist id="bill-companies">
                {names.map((name) => (
                  <option key={name} value={name} />
                ))}
              </datalist>
            </Field>
            <Field label="Cylinder type">
              <input className="field" value={cylinderType} list="bill-types" onChange={(event) => setCylinderType(event.target.value)} placeholder="Oxygen 47L" />
              <datalist id="bill-types">
                {cylinderTypeOptions(entries.map((entry) => entry.cylinderType)).map((name) => (
                  <option key={name} value={name} />
                ))}
              </datalist>
            </Field>
            <Field label="Serial numbers" hint={counted.length ? `${counted.length} counted` : "The quantity follows these serials."}>
              <textarea className="field field-area min-h-24" value={serialNo} onChange={(event) => onSerials(event.target.value)} />
            </Field>
            <button
              type="button"
              role="switch"
              aria-checked={qtyOverride}
              className="btn btn-ghost justify-between"
              onClick={() => {
                const next = !qtyOverride;
                setQtyOverride(next);
                const nextQty = next ? quantity || counted.length || 1 : counted.length;
                setQuantity(nextQty);
                if (!finalTouched) setFinalAmount(subtotal(nextQty, price));
              }}
            >
              Override quantity
              <span className={cn("inline-flex h-7 w-12 items-center rounded-full p-1", qtyOverride ? "bg-pine" : "bg-line")}>
                <span className={cn("size-5 rounded-full bg-card", qtyOverride && "ml-auto")} />
              </span>
            </button>
            <Field label="Cylinders">
              <input
                className={cn("field tabular-nums", !qtyOverride && "bg-sand")}
                readOnly={!qtyOverride}
                inputMode="numeric"
                value={String(qty)}
                onChange={(event) => {
                  const nextQty = Number(event.target.value.replace(/[^\d]/g, "") || "0");
                  setQuantity(nextQty);
                  if (!finalTouched) setFinalAmount(subtotal(nextQty, price));
                }}
              />
            </Field>
            <Field label="Price per cylinder (₹)">
              <input
                className="field tabular-nums"
                inputMode="decimal"
                value={price ?? ""}
                onChange={(event) => {
                  const next = money(event.target.value);
                  setPrice(next);
                  if (!finalTouched) setFinalAmount(subtotal(qty, next));
                }}
              />
            </Field>
            <p className="text-sm">Subtotal {rupee(goods)}</p>
            <Field label="Final amount (₹)">
              <input
                className="field tabular-nums"
                inputMode="decimal"
                value={total ?? ""}
                onChange={(event) => {
                  setFinalTouched(true);
                  setFinalAmount(money(event.target.value));
                }}
              />
            </Field>
            <div className="grid grid-cols-3 gap-2">
              {(["received", "partial", "unpaid"] as const).map((item) => (
                <button key={item} type="button" className={cn("btn px-2 text-xs", payment === item ? "btn-pine" : "btn-ghost")} onClick={() => setPayment(item)}>
                  {paymentLabel(item)}
                </button>
              ))}
            </div>
            <Field label="Amount received (₹)">
              <input className="field tabular-nums" inputMode="decimal" value={paid ?? ""} onChange={(event) => setPaid(money(event.target.value))} />
            </Field>
            <Field label="Notes">
              <input className="field" value={note} maxLength={300} onChange={(event) => setNote(event.target.value)} />
            </Field>
            {error ? <p className="text-sm text-rust">{error}</p> : null}
            {saved ? <p className="text-sm text-pine">{saved}</p> : null}
            <button type="button" className="btn btn-rust" disabled={pending} onClick={() => void save()}>
              {pending ? "Saving…" : "Save bill"}
            </button>
          </div>
        </Panel>
        <Panel title="Preview">
          <article className="rounded-xl border border-line bg-paper p-4 text-sm">
            {yard.logo ? <img src={yard.logo} alt="" className="mb-3 h-12 w-auto" /> : null}
            <h3 className="font-display text-2xl">{yard.name}</h3>
            {yard.address ? <p className="mt-1 whitespace-pre-wrap text-muted">{yard.address}</p> : null}
            <p className="mt-1 text-muted">
              {[yard.phone && `Phone ${yard.phone}`, yard.gst && `GST ${yard.gst}`, yard.pan && `PAN ${yard.pan}`].filter(Boolean).join(" · ") || "Add letterhead in Setup."}
            </p>
            <p className="mt-4 font-medium">{kind === "sale" ? "Sale bill" : "Purchase bill"} {billNo}</p>
            <p>{date} · {company || "Company"}</p>
            <p className="mt-3 whitespace-pre-wrap">{counted.join("\n") || "No serials yet"}</p>
            <p className="mt-3 tabular-nums">
              {qty} × {rupee(price)} = {rupee(goods)}
            </p>
            <p className="font-semibold">Final {rupee(total)}</p>
            <p className="text-muted">{paymentLabel(payment)}{paid != null ? ` · received ${rupee(paid)}` : ""}</p>
            {note ? <p className="mt-2">{note}</p> : null}
          </article>
          <div className="mt-4">
            <ExportBar title={`${billNo || "Bill"} · ${yard.name}`} filename={billNo || "cxyledge-bill"} lines={lines} csv={csv} />
          </div>
        </Panel>
      </div>
    </div>
  );
}

function money(raw: string): number | null {
  const cleaned = raw.replace(/[^\d.]/g, "");
  if (!cleaned) return null;
  const value = Number(cleaned);
  return Number.isFinite(value) ? value : null;
}

function billLines(input: {
  yard: YardInfo;
  kind: BillKind;
  billNo: string;
  date: string;
  company: string;
  serials: string[];
  quantity: number;
  price: number | null;
  total: number | null;
  payment: PaymentStatus;
  paid: number | null;
  note: string;
  cylinderType?: string;
}): string[] {
  return [
    input.yard.name,
    input.yard.address,
    [input.yard.phone, input.yard.gst && `GST ${input.yard.gst}`, input.yard.pan && `PAN ${input.yard.pan}`].filter(Boolean).join("  "),
    "",
    input.kind === "sale" ? "SALE BILL" : "PURCHASE BILL",
    `Bill ${input.billNo}`,
    `Date ${input.date}`,
    `Company ${input.company}`,
    "",
    "Serials",
    ...(input.serials.length ? input.serials : ["—"]),
    "",
    `Cylinders ${input.quantity}${input.cylinderType ? ` × ${input.cylinderType}` : ""}`,
    `Price ${rupee(input.price)}`,
    `Amount ${rupee(input.total)}`,
    `Payment ${paymentLabel(input.payment)}`,
    `Received ${rupee(input.paid)}`,
    input.note,
    "",
    "Cxyledge",
  ].filter((line) => line != null);
}
