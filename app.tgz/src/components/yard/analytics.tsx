import { useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Entry, PaymentStatus } from "@/lib/inventory/api";
import {
  inRange,
  movementLabel,
  movementSeries,
  paymentLabel,
  periodBounds,
  topCompanies,
  totalsFor,
  type Period,
} from "@/lib/inventory/analyse";
import { formatDay, todayISO } from "@/lib/inventory/model";
import { rupee } from "@/lib/inventory/serials";
import { toCsv } from "@/lib/inventory/files";
import { cn } from "@/lib/cn";
import { ExportBar } from "@/components/yard/export-bar";
import { Panel, Stat } from "@/components/yard/ui";

const PERIODS: Array<{ id: Period; label: string }> = [
  { id: "day", label: "Day" },
  { id: "week", label: "Week" },
  { id: "month", label: "Month" },
  { id: "year", label: "Year" },
  { id: "custom", label: "Custom" },
];

export default function AnalyticsView({ entries, yardName }: { entries: Entry[]; yardName: string }) {
  const [period, setPeriod] = useState<Period>("month");
  const [customFrom, setCustomFrom] = useState("");
  const [customTo, setCustomTo] = useState("");
  const [company, setCompany] = useState("all");
  const [status, setStatus] = useState<PaymentStatus | "all">("all");
  const today = todayISO();
  const bounds = periodBounds(period, today, customFrom || today, customTo || today);
  const companies = useMemo(() => [...new Set(entries.map((entry) => entry.companyName))].sort(), [entries]);

  const scoped = useMemo(() => {
    return entries.filter((entry) => {
      if (company !== "all" && entry.companyName !== company) return false;
      if (!inRange(entry, bounds.from, bounds.to)) return false;
      if (status !== "all" && entry.movement !== "return" && entry.paymentStatus !== status) return false;
      return true;
    });
  }, [entries, company, bounds.from, bounds.to, status]);

  const moneyRows = scoped.filter((entry) => status === "all" || entry.movement === "return" || entry.paymentStatus === status);
  const totals = totalsFor(moneyRows);
  const series = useMemo(() => movementSeries(scoped.filter((entry) => status === "all" || entry.paymentStatus === status || entry.movement === "return"), bounds.from, bounds.to), [scoped, bounds.from, bounds.to, status]);
  const leaders = topCompanies(scoped.filter((entry) => entry.movement === "delivery"));
  const busiest = [...series].sort((a, b) => b.delivered - a.delivered)[0];

  const lines = [
    `${yardName} · ${bounds.label}`,
    `${bounds.from} to ${bounds.to}`,
    company === "all" ? "All companies" : company,
    "",
    `Billed ${rupee(totals.billed)}`,
    `Received ${rupee(totals.paid)}`,
    `To collect ${rupee(totals.toCollect)}`,
    `To pay ${rupee(totals.toPay)}`,
    `Overdue (open more than 7 days) ${rupee(totals.overdue)}`,
    `Delivered ${totals.delivered}`,
    `Returned ${totals.returned}`,
    `Purchased ${totals.purchased}`,
    "",
    "Date | Company | Movement | Qty | Serials | Bill | Payment | Due | Paid",
    ...scoped.map(
      (entry) =>
        `${entry.entryDate} | ${entry.companyName} | ${movementLabel(entry.movement)} | ${entry.quantity} | ${entry.serialNo.replace(/\n/g, " ")} | ${entry.billNo} | ${paymentLabel(entry.paymentStatus)} | ${entry.amountDue ?? ""} | ${entry.amountPaid ?? ""}`,
    ),
  ];
  const csv = toCsv(
    ["Date", "Company", "Movement", "Qty", "Serials", "Bill", "Payment", "Due", "Paid", "Note"],
    scoped.map((entry) => [
      entry.entryDate,
      entry.companyName,
      movementLabel(entry.movement),
      String(entry.quantity),
      entry.serialNo.replace(/\n/g, " "),
      entry.billNo,
      paymentLabel(entry.paymentStatus),
      entry.amountDue == null ? "" : String(entry.amountDue),
      entry.amountPaid == null ? "" : String(entry.amountPaid),
      entry.note,
    ]),
  );

  if (entries.length === 0) {
    return (
      <Panel title="Nothing to analyse yet">
        <p className="text-sm text-muted">Add deliveries in the book, or load the sample week. Day, week, month, and year totals show up here.</p>
      </Panel>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div>
        <h2 className="font-display text-3xl">Analytics</h2>
        <p className="mt-1 text-sm text-muted">Payment balance and cylinder movement for {bounds.label.toLowerCase()}.</p>
      </div>
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
        {PERIODS.map((item) => (
          <button key={item.id} type="button" className={cn("btn px-2 text-sm", period === item.id ? "btn-pine" : "btn-ghost")} onClick={() => setPeriod(item.id)}>
            {item.label}
          </button>
        ))}
      </div>
      {period === "custom" ? (
        <div className="grid grid-cols-2 gap-2">
          <input type="date" className="field" aria-label="From" value={customFrom} onChange={(event) => setCustomFrom(event.target.value)} />
          <input type="date" className="field" aria-label="To" value={customTo} onChange={(event) => setCustomTo(event.target.value)} />
        </div>
      ) : null}
      <div className="grid gap-2 sm:grid-cols-2">
        <select className="field" aria-label="Company" value={company} onChange={(event) => setCompany(event.target.value)}>
          <option value="all">All companies</option>
          {companies.map((name) => (
            <option key={name} value={name}>
              {name}
            </option>
          ))}
        </select>
        <select className="field" aria-label="Payment" value={status} onChange={(event) => setStatus(event.target.value as PaymentStatus | "all")}>
          <option value="all">Any payment</option>
          <option value="unpaid">Not received</option>
          <option value="partial">Part received</option>
          <option value="received">Received</option>
        </select>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Stat label="To collect" value={rupee(totals.toCollect, 0)} tone="rust" />
        <Stat label="Received" value={rupee(totals.paid, 0)} tone="pine" />
        <Stat label="To pay" value={rupee(totals.toPay, 0)} />
        <Stat label="Overdue" value={rupee(totals.overdue, 0)} tone="rust" />
      </div>
      <div className="grid grid-cols-3 gap-3">
        <Stat label="Delivered" value={totals.delivered} />
        <Stat label="Returned" value={totals.returned} tone="pine" />
        <Stat label="Purchased" value={totals.purchased} />
      </div>

      <Panel>
        <p className="text-sm leading-relaxed">
          {totals.delivered} cylinders went out and {totals.returned} came back in this stretch.
          {busiest && busiest.delivered > 0 ? ` Busiest point: ${busiest.label}, ${busiest.delivered} delivered.` : ""}
          {leaders[0] ? ` ${leaders[0].company} leads unpaid delivery balance at ${rupee(leaders[0].balance, 0)}.` : ""}
          {totals.overdue > 0 ? ` ${rupee(totals.overdue, 0)} has been open more than a week.` : " Nothing is overdue past a week."}
        </p>
      </Panel>

      <Panel title="Delivered and returned">
        <div className="h-64 w-full min-w-0">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={series} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="var(--color-line)" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
              <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} width={32} allowDecimals={false} />
              <Tooltip cursor={{ fill: "var(--color-sand)" }} content={<ChartTip />} />
              <Bar dataKey="delivered" fill="var(--color-rust)" radius={[4, 4, 0, 0]} maxBarSize={18} />
              <Bar dataKey="returned" fill="var(--color-pine)" radius={[4, 4, 0, 0]} maxBarSize={18} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <Panel title="Outstanding cylinders">
        <div className="h-56 w-full min-w-0">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={series} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="var(--color-line)" vertical={false} />
              <XAxis dataKey="label" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
              <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} width={32} allowDecimals={false} />
              <Tooltip content={<ChartTip />} />
              <Line type="monotone" dataKey="outstanding" stroke="var(--color-ink)" strokeWidth={2} dot={false} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <Panel title="Companies">
        {leaders.length === 0 ? (
          <p className="text-sm text-muted">No deliveries in this range.</p>
        ) : (
          <ul className="flex flex-col gap-2">
            {leaders.map((row) => (
              <li key={row.company} className="flex items-center justify-between gap-3 text-sm">
                <span className="min-w-0 truncate font-medium">{row.company}</span>
                <span className="shrink-0 tabular-nums text-muted">
                  {row.cylinders} · {rupee(row.balance, 0)}
                </span>
              </li>
            ))}
          </ul>
        )}
      </Panel>

      <Panel title="Transactions">
        <ul className="flex flex-col gap-3">
          {scoped.slice(0, 40).map((entry) => (
            <li key={entry.id} className="border-b border-line pb-3 text-sm last:border-0 last:pb-0">
              <p className="font-medium">
                {entry.companyName} · {movementLabel(entry.movement)} · {entry.quantity}
              </p>
              <p className="text-muted">
                {formatDay(entry.entryDate)} · {paymentLabel(entry.paymentStatus)} · {rupee(entry.amountDue)}
                {entry.serialNo ? ` · ${entry.serialNo.replace(/\n/g, ", ")}` : ""}
              </p>
            </li>
          ))}
        </ul>
        {scoped.length > 40 ? <p className="mt-3 text-xs text-muted">Showing 40 of {scoped.length}. The export includes every row.</p> : null}
      </Panel>

      <Panel title="Export this view">
        <ExportBar title={`${yardName} analytics`} filename="cxyledge-analytics" lines={lines} csv={csv} />
      </Panel>
    </div>
  );
}

function ChartTip({
  active,
  payload,
  label,
}: {
  active?: boolean;
  payload?: Array<{ name?: string; value?: number; dataKey?: string }>;
  label?: string;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-lg border border-line bg-card px-3 py-2 text-sm">
      <p className="font-medium">{label}</p>
      {payload.map((item) => (
        <p key={String(item.dataKey)} className="tabular-nums text-muted">
          {item.dataKey} {item.value}
        </p>
      ))}
    </div>
  );
}
