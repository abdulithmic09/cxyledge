import { useMemo, useState } from "react";
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import type { Entry, PaymentStatus } from "@/lib/inventory/api";
import { cn } from "@/lib/cn";
import { Panel, Stat } from "@/components/yard/ui";

const RANGES = [
  { id: 7, label: "7 days" },
  { id: 30, label: "30 days" },
  { id: 0, label: "All" },
] as const;

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function addDays(iso: string, n: number) {
  const [y, m, d] = iso.split("-").map(Number);
  const dt = new Date(y!, (m ?? 1) - 1, d ?? 1);
  dt.setDate(dt.getDate() + n);
  return `${dt.getFullYear()}-${String(dt.getMonth() + 1).padStart(2, "0")}-${String(dt.getDate()).padStart(2, "0")}`;
}

function shortDay(iso: string) {
  const [y, m, d] = iso.split("-").map(Number);
  return new Date(y!, (m ?? 1) - 1, d ?? 1).toLocaleDateString("en-IN", { day: "numeric", month: "short" });
}

function rupee(n: number) {
  return new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(n);
}

export default function SummaryView({ entries }: { entries: Entry[] }) {
  const [range, setRange] = useState<(typeof RANGES)[number]["id"]>(30);
  const today = todayISO();
  const from = range === 0 ? "" : addDays(today, -(range - 1));
  const rows = entries.filter((e) => !from || e.entryDate >= from);

  const totals = useMemo(() => {
    const by: Record<PaymentStatus, number> = { received: 0, partial: 0, unpaid: 0 };
    let due = 0;
    let paid = 0;
    for (const e of rows) {
      by[e.paymentStatus] += e.quantity;
      due += e.amountDue ?? 0;
      paid += e.amountPaid ?? 0;
    }
    return { by, cylinders: rows.reduce((a, e) => a + e.quantity, 0), due, paid, outstanding: Math.max(0, due - paid) };
  }, [rows]);

  const chart = useMemo(() => {
    const map = new Map<string, number>();
    for (const e of rows) map.set(e.entryDate, (map.get(e.entryDate) ?? 0) + e.quantity);
    return [...map.entries()]
      .sort(([a], [b]) => (a < b ? -1 : 1))
      .slice(-30)
      .map(([date, cylinders]) => ({ label: shortDay(date), cylinders }));
  }, [rows]);

  const companies = useMemo(() => {
    const map = new Map<string, { company: string; cylinders: number; unpaid: number; partial: number; outstanding: number }>();
    for (const e of rows) {
      const row = map.get(e.companyName) ?? { company: e.companyName, cylinders: 0, unpaid: 0, partial: 0, outstanding: 0 };
      row.cylinders += e.quantity;
      if (e.paymentStatus === "unpaid") row.unpaid += e.quantity;
      if (e.paymentStatus === "partial") row.partial += e.quantity;
      row.outstanding += Math.max(0, (e.amountDue ?? 0) - (e.amountPaid ?? 0));
      map.set(e.companyName, row);
    }
    return [...map.values()].sort((a, b) => b.unpaid + b.partial - (a.unpaid + a.partial) || b.cylinders - a.cylinders);
  }, [rows]);

  if (entries.length === 0) {
    return (
      <Panel title="Nothing to summarise yet">
        <p className="text-sm text-muted">Add entries in the book. Totals here follow the shared yard, so they match every device.</p>
      </Panel>
    );
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h2 className="font-display text-3xl">Summary</h2>
          <p className="mt-1 text-sm text-muted">Cylinders and payment across the shared book.</p>
        </div>
        <div className="grid grid-cols-3 gap-2">
          {RANGES.map((r) => (
            <button
              key={r.id}
              type="button"
              className={cn("btn px-2 text-sm", range === r.id ? "btn-pine" : "btn-ghost")}
              onClick={() => setRange(r.id)}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <Stat label="Cylinders" value={totals.cylinders} tone="pine" />
        <Stat label="Not received" value={totals.by.unpaid} tone="rust" />
        <Stat label="Partial" value={totals.by.partial} />
        <Stat label="Received" value={totals.by.received} tone="pine" />
      </div>
      <Panel>
        <p className="text-sm leading-relaxed">
          {totals.cylinders} cylinders in this stretch. {totals.by.unpaid} are still unpaid
          {totals.by.partial ? ` and ${totals.by.partial} are only partly paid` : ""}.
          {totals.due > 0 ? ` Amount due ${rupee(totals.due)}, received ${rupee(totals.paid)}, still open ${rupee(totals.outstanding)}.` : " No rupee amounts were entered."}
        </p>
      </Panel>
      {chart.length > 0 ? (
        <Panel title="Cylinders by day">
          <div className="h-64 w-full min-w-0">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chart} margin={{ top: 8, right: 4, left: 0, bottom: 0 }}>
                <CartesianGrid stroke="var(--color-line)" vertical={false} />
                <XAxis dataKey="label" tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} interval="preserveStartEnd" />
                <YAxis tick={{ fill: "var(--color-muted)", fontSize: 12 }} axisLine={false} tickLine={false} width={32} allowDecimals={false} />
                <Tooltip
                  cursor={{ fill: "var(--color-sand)" }}
                  content={({ active, payload, label }) =>
                    active && payload?.length ? (
                      <div className="rounded-lg border border-line bg-card px-3 py-2 text-sm">
                        <p className="font-medium">{label}</p>
                        <p className="tabular-nums text-muted">{payload[0]?.value} cylinders</p>
                      </div>
                    ) : null
                  }
                />
                <Bar dataKey="cylinders" fill="var(--color-rust)" radius={[4, 4, 0, 0]} maxBarSize={28} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>
      ) : null}
      <Panel title="By company">
        <ul className="divide-y divide-line">
          {companies.map((c) => (
            <li key={c.company} className="flex items-start justify-between gap-3 py-3 first:pt-0 last:pb-0">
              <div className="min-w-0">
                <p className="truncate font-medium">{c.company}</p>
                <p className="text-sm text-muted">
                  {c.unpaid ? `${c.unpaid} not received` : "none unpaid"}
                  {c.partial ? ` · ${c.partial} partial` : ""}
                </p>
              </div>
              <p className="shrink-0 text-right text-sm tabular-nums">
                <span className="block font-semibold">{c.cylinders}</span>
                {c.outstanding > 0 ? <span className="text-rust">{rupee(c.outstanding)}</span> : <span className="text-muted">clear</span>}
              </p>
            </li>
          ))}
        </ul>
      </Panel>
    </div>
  );
}
